# MEMORY CYCLE v4 — three fair paired synthetic simulations

Date: 2026-08-04

These are engineering simulations, not Claude API evidence. They test mechanics and cannot confirm the preregistered 20% token-reduction hypothesis.

Each scenario used 10 SWARM agents and 10 baseline agents, 16 tasks per agent, up to 3 attempts, common random numbers for paired task-attempt observations, and identical task difficulty for both conditions.

| Scenario | SWARM passed | Baseline passed | SWARM attempts | Baseline attempts | Token reduction | Memory calls | Retry memory calls |
|---|---:|---:|---:|---:|---:|---:|---:|
| Relevant prior-cycle memory | 159/160 | 159/160 | 207 | 218 | **1.50%** | 80 | 0 |
| Irrelevant noise | 160/160 | 160/160 | 214 | 214 | **0.00%** | 0 | 0 |
| Paired first-cycle failure purge | 80/160 | 80/160 | 353 | 353 | **0.00%** | 0 | 0 |

## What was verified

1. Relevant intuition was available only after the state-40 threshold and reduced attempts in the synthetic relevant-memory scenario.
2. Unrelated memory was fully rejected, giving identical SWARM and baseline behavior.
3. In the failure-purge stress case, both conditions received exactly 240 forced-failure calls. SWARM retained no failure memory and matched baseline exactly afterward.
4. Intuitive memory was never present on a retry.

## Statistical verdict

All three synthetic reports returned `NOT_CONFIRMED`; the 20% gate was not met. That is the correct verdict.
