# MEMORY CYCLE v4 — verified test runs

Date: 2026-08-04

Target layout: current GitHub `validation_10x10` plus the v4 overlay.

## Static check

- `python -m compileall -q swarm_validation scripts` — passed.

## Unit and integration tests

The complete target suite contains 19 tests. It was executed three times from a clean copied tree.

| Run | Result | Duration |
|---|---:|---:|
| 1 | 19/19 passed | 1.291 s |
| 2 | 19/19 passed | 1.324 s |
| 3 | 19/19 passed | 1.093 s |

Total: **57/57 passed**.

Covered behavior includes:

- `ROZPAD II → 3 → 6 → 28 → 40`,
- reset only while crossing `40 → NEW CYCLE`,
- complete destruction of failure memory at state 6,
- no raw code in intuitive memory,
- no use of same-cycle working memory,
- relevance rejection for unrelated intuition,
- intuition removal on retries while local error feedback remains,
- corrected fuel direction,
- 10×10 runner, checkpoint resume, statistical report and 960-call guard.
