#!/usr/bin/env bash
set -euo pipefail

PACKAGE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$PACKAGE_DIR/.." && pwd)"
cd "$REPO_ROOT"

if [[ ! -d validation_10x10/swarm_validation ]]; then
  echo "Run this script from the extracted package inside the swarm-os-benchmark repository." >&2
  exit 1
fi

git fetch origin
git switch main
git pull --ff-only
git switch -C agent/related-projects-pilot

python "$PACKAGE_DIR/apply_related_projects_patch.py"

cp "$PACKAGE_DIR/validation_10x10/examples/related_projects_pilot.json" \
  validation_10x10/examples/related_projects_pilot.json
cp "$PACKAGE_DIR/validation_10x10/scripts/generate_related_projects.py" \
  validation_10x10/scripts/generate_related_projects.py
cp "$PACKAGE_DIR/validation_10x10/swarm_validation/tests/test_related_projects.py" \
  validation_10x10/swarm_validation/tests/test_related_projects.py
cp "$PACKAGE_DIR/validation_10x10/RELATED_PROJECTS_PILOT.md" \
  validation_10x10/RELATED_PROJECTS_PILOT.md
chmod +x validation_10x10/scripts/generate_related_projects.py

cd validation_10x10
python scripts/generate_related_projects.py --output data/related_projects_pilot.jsonl
python -m py_compile swarm_validation/protocol.py swarm_validation/controller.py \
  swarm_validation/runner.py swarm_validation/analysis.py \
  scripts/generate_related_projects.py
python -m unittest discover -s swarm_validation/tests -v
cd "$REPO_ROOT"

git add validation_10x10
git commit -m "Add related-projects memory pilot" || true
git push -u origin agent/related-projects-pilot --force-with-lease

PR_URL="$(gh pr view --repo lukaszsaczo-cyber/swarm-os-benchmark --json url -q .url 2>/dev/null || true)"
if [[ -z "$PR_URL" ]]; then
  PR_URL="$(gh pr create \
    --repo lukaszsaczo-cyber/swarm-os-benchmark \
    --base main \
    --head agent/related-projects-pilot \
    --title "Add related-projects SWARM memory pilot" \
    --body-file validation_10x10/RELATED_PROJECTS_PILOT.md)"
fi

echo "PILOT CODE FROZEN AND PUSHED"
echo "$PR_URL"
