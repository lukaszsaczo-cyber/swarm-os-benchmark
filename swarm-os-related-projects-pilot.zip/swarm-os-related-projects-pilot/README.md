# SWARM_OS Related Projects Pilot package

This overlay adds an exploratory 10-vs-10 live API benchmark with 10 ordered projects and 8 related steps per project.

## One-command start inside Codespace

After uploading and extracting this ZIP in the repository root:

```bash
cd /workspaces/swarm-os-benchmark && \
unzip -o swarm-os-related-projects-pilot.zip && \
bash swarm-os-related-projects-pilot/START_RELATED_PROJECTS_PILOT.sh
```

The script freezes and pushes the benchmark code before spending API credit, runs unit tests, creates a pull request, runs the live pilot, hashes the evidence, commits the final report and prints the result.

## Safety and interpretation

- Maximum live API calls: 480.
- Model: `claude-sonnet-4-6`.
- Prompt caching: disabled.
- This pilot is exploratory because it was designed after the HumanEval result.
- A company-facing confirmatory claim requires a new frozen blind holdout after this pilot.
