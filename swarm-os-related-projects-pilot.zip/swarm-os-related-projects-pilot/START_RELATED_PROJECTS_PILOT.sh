#!/usr/bin/env bash
set -euo pipefail
PACKAGE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
bash "$PACKAGE_DIR/APPLY_RELATED_PROJECTS_PILOT.sh"
bash "$PACKAGE_DIR/RUN_RELATED_PROJECTS_PILOT.sh"
