#!/usr/bin/env bash
set -euo pipefail

PACKAGE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$PACKAGE_DIR/.." && pwd)"
cd "$REPO_ROOT/validation_10x10"

if [[ -z "${ANTHROPIC_API_KEY:-}" ]]; then
  echo "BŁĄD: brak ANTHROPIC_API_KEY w Codespace" >&2
  exit 1
fi

if [[ -d .venv ]]; then
  source .venv/bin/activate
fi
python -m pip install -q -e .

OUT="results/live-related-projects-pilot-2026-08-06-r1"
rm -rf "$OUT"
mkdir -p "$OUT"

python -m swarm_validation.cli plan \
  --config examples/related_projects_pilot.json \
  --tasks data/related_projects_pilot.jsonl \
  --output-dir "$OUT" | tee "$OUT/plan.log"

python -m swarm_validation.cli run \
  --config examples/related_projects_pilot.json \
  --tasks data/related_projects_pilot.jsonl \
  --output-dir "$OUT" \
  --confirm-live-run RUN_10X10_CLAUDE_VALIDATION \
  2>&1 | tee "$OUT/console.log"

sha256sum "$OUT"/manifest.json "$OUT"/attempts.jsonl "$OUT"/outcomes.jsonl \
  "$OUT"/report.json "$OUT"/report.md > "$OUT/EVIDENCE_SHA256.txt"

cd "$REPO_ROOT"
git add \
  "validation_10x10/$OUT/manifest.json" \
  "validation_10x10/$OUT/outcomes.jsonl" \
  "validation_10x10/$OUT/report.json" \
  "validation_10x10/$OUT/report.md" \
  "validation_10x10/$OUT/EVIDENCE_SHA256.txt"
git commit -m "Add live related-projects pilot result" || true
git push origin agent/related-projects-pilot

cat "validation_10x10/$OUT/report.md"
