#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
V = ROOT / "validation_10x10"


def replace_once(path: Path, old: str, new: str) -> None:
    text = path.read_text(encoding="utf-8")
    if new in text:
        return
    if old not in text:
        raise SystemExit(f"Patch anchor not found in {path}: {old[:90]!r}")
    path.write_text(text.replace(old, new, 1), encoding="utf-8")


def patch_protocol() -> None:
    path = V / "swarm_validation" / "protocol.py"
    replace_once(
        path,
        '    call_order_seed: int = 330016\n',
        '    call_order_seed: int = 330016\n    assignment_mode: str = "shuffled"\n',
    )
    replace_once(
        path,
        '    max_prompt_memory_entries: int = 1\n',
        '    max_prompt_memory_entries: int = 1\n'
        '    max_working_prompt_entries: int = 1\n'
        '    working_memory_min_quality: float = 0.70\n',
    )
    replace_once(
        path,
        '        if self.tasks_per_agent < 1 or self.max_attempts < 1 or self.cycle_length < 1:\n',
        '        if self.assignment_mode not in {"shuffled", "project_sequence"}:\n'
        '            raise ValueError("assignment_mode must be shuffled or project_sequence")\n'
        '        if self.tasks_per_agent < 1 or self.max_attempts < 1 or self.cycle_length < 1:\n',
    )
    replace_once(
        path,
        '            "memory_recall_fuel": self.memory_recall_fuel,\n',
        '            "memory_recall_fuel": self.memory_recall_fuel,\n'
        '            "working_memory_min_quality": self.working_memory_min_quality,\n',
    )
    old = '''def assign_tasks(tasks: list[BenchmarkTask], config: ProtocolConfig) -> dict[int, list[BenchmarkTask]]:\n    config.validate()\n    needed = config.agents_per_condition * config.tasks_per_agent\n    if len(tasks) < needed:\n        raise ValueError(f"Dataset has {len(tasks)} tasks; final protocol requires at least {needed}")\n    selected = list(tasks)\n    random.Random(config.assignment_seed).shuffle(selected)\n    selected = selected[:needed]\n    return {\n        agent_id: selected[\n            agent_id * config.tasks_per_agent : (agent_id + 1) * config.tasks_per_agent\n        ]\n        for agent_id in range(config.agents_per_condition)\n    }\n\n\n'''
    new = '''def assign_tasks(tasks: list[BenchmarkTask], config: ProtocolConfig) -> dict[int, list[BenchmarkTask]]:\n    config.validate()\n    needed = config.agents_per_condition * config.tasks_per_agent\n    if len(tasks) < needed:\n        raise ValueError(f"Dataset has {len(tasks)} tasks; final protocol requires at least {needed}")\n\n    if config.assignment_mode == "project_sequence":\n        grouped: dict[str, list[BenchmarkTask]] = {}\n        for task in tasks:\n            metadata = task.metadata or {}\n            project_id = metadata.get("project_id")\n            step_index = metadata.get("step_index")\n            if not isinstance(project_id, str) or not project_id:\n                raise ValueError(f"Task {task.task_id} is missing project_id metadata")\n            if not isinstance(step_index, int):\n                raise ValueError(f"Task {task.task_id} is missing integer step_index metadata")\n            grouped.setdefault(project_id, []).append(task)\n\n        eligible: list[tuple[str, list[BenchmarkTask]]] = []\n        for project_id, project_tasks in grouped.items():\n            ordered = sorted(project_tasks, key=lambda item: int((item.metadata or {})["step_index"]))\n            steps = [int((item.metadata or {})["step_index"]) for item in ordered]\n            if len(ordered) >= config.tasks_per_agent and steps[: config.tasks_per_agent] == list(\n                range(1, config.tasks_per_agent + 1)\n            ):\n                eligible.append((project_id, ordered[: config.tasks_per_agent]))\n\n        if len(eligible) < config.agents_per_condition:\n            raise ValueError(\n                f"Dataset has {len(eligible)} complete project sequences; "\n                f"protocol requires {config.agents_per_condition}"\n            )\n        random.Random(config.assignment_seed).shuffle(eligible)\n        selected_projects = eligible[: config.agents_per_condition]\n        return {agent_id: tasks for agent_id, (_, tasks) in enumerate(selected_projects)}\n\n    selected = list(tasks)\n    random.Random(config.assignment_seed).shuffle(selected)\n    selected = selected[:needed]\n    return {\n        agent_id: selected[\n            agent_id * config.tasks_per_agent : (agent_id + 1) * config.tasks_per_agent\n        ]\n        for agent_id in range(config.agents_per_condition)\n    }\n\n\n'''
    replace_once(path, old, new)


def patch_controller() -> None:
    path = V / "swarm_validation" / "controller.py"
    replace_once(
        path,
        '    max_prompt_memory_entries: int = 1\n',
        '    max_prompt_memory_entries: int = 1\n'
        '    max_working_prompt_entries: int = 1\n'
        '    working_memory_min_quality: float = 0.70\n',
    )
    replace_once(
        path,
        'def _generalize(task: BenchmarkTask, completion: str) -> tuple[str, list[str]]:\n',
        'def _project_key(task_id: str) -> str | None:\n'
        '    if "::" not in task_id:\n'
        '        return None\n'
        '    return task_id.split("::", 1)[0]\n\n\n'
        'def _project_convention(task: BenchmarkTask) -> str:\n'
        '    match = re.search(r"^#?\\s*Project convention:\\s*(.+)$", task.prompt, re.MULTILINE)\n'
        '    return " ".join(match.group(1).split())[:120] if match else ""\n\n\n'
        'def _generalize(task: BenchmarkTask, completion: str) -> tuple[str, list[str]]:\n',
    )
    replace_once(
        path,
        '    technique = _features(completion, task.entry_point)[0]\n    return f"{domain}: {technique}; boundary guards."[:120], keys\n',
        '    technique = _features(completion, task.entry_point)[0]\n'
        '    convention = _project_convention(task)\n'
        '    lesson = f"{domain}: {technique}; boundary guards."\n'
        '    if convention:\n'
        '        lesson += f" Project convention: {convention}"\n'
        '    return lesson[:220], keys\n',
    )
    anchor = '''    def system_prompt(self, task: BenchmarkTask) -> str:\n        self._cross_threshold_40()\n        selected = self._select(task)\n        if not selected:\n            return BASE_SYSTEM\n        memory = "\\n".join(f"- {entry.lesson}" for entry in selected)\n        return BASE_SYSTEM + "\\n\\nPrior-cycle intuition:\\n" + memory\n'''
    replacement = '''    def _select_working(self, task: BenchmarkTask) -> list[WorkingObservation]:\n        if self.max_working_prompt_entries <= 0:\n            return []\n        if self.state.fuel < self.memory_recall_fuel:\n            return []\n        if self.state.phase in {"ROZPAD_I", "STAGNACJA", "PĘKNIĘCIE", "ROZPAD_II"}:\n            return []\n        project = _project_key(task.task_id)\n        if project is None:\n            return []\n\n        task_words = set(_keywords(task.prompt + " " + task.entry_point))\n        scored: list[tuple[int, float, float, int, WorkingObservation]] = []\n        for observation in self.working_memory:\n            if not observation.passed or observation.quality < self.working_memory_min_quality:\n                continue\n            if _project_key(observation.task_id) != project:\n                continue\n            words = set(observation.keywords)\n            overlap = len(task_words & words)\n            union = len(task_words | words) or 1\n            jaccard = overlap / union\n            if overlap < self.min_keyword_overlap or jaccard < self.min_jaccard:\n                continue\n            scored.append((overlap, jaccard, observation.quality, observation.cycle_index, observation))\n        scored.sort(reverse=True, key=lambda item: item[:4])\n        return [item[-1] for item in scored[: self.max_working_prompt_entries]]\n\n    def system_prompt(self, task: BenchmarkTask) -> str:\n        self._cross_threshold_40()\n        intuitive = self._select(task)\n        working = self._select_working(task)\n        sections: list[str] = []\n        if intuitive:\n            sections.append(\n                "Prior-cycle intuition:\\n"\n                + "\\n".join(f"- {entry.lesson}" for entry in intuitive)\n            )\n        if working:\n            sections.append(\n                "Current-cycle working guidance:\\n"\n                + "\\n".join(f"- {entry.lesson}" for entry in working)\n            )\n        return BASE_SYSTEM if not sections else BASE_SYSTEM + "\\n\\n" + "\\n\\n".join(sections)\n'''
    replace_once(path, anchor, replacement)


def patch_runner() -> None:
    path = V / "swarm_validation" / "runner.py"
    replace_once(
        path,
        '        max_prompt_memory_entries=config.max_prompt_memory_entries,\n',
        '        max_prompt_memory_entries=config.max_prompt_memory_entries,\n'
        '        max_working_prompt_entries=config.max_working_prompt_entries,\n'
        '        working_memory_min_quality=config.working_memory_min_quality,\n',
    )
    replace_once(
        path,
        '            "prompt_caching": False,\n',
        '            "prompt_caching": False,\n'
        '            "assignment_mode": config.assignment_mode,\n'
        '            "project_sequence_memory": "passed same-project working evidence only; retries never receive memory",\n',
    )


def patch_analysis() -> None:
    path = V / "swarm_validation" / "analysis.py"
    old_summary = '''    def summary(items: list[TaskOutcome]) -> dict[str, Any]:\n        return {\n            "observations": len(items),\n            "passed": sum(item.passed for item in items),\n            "pass_rate": sum(item.passed for item in items) / len(items),\n            "attempts": sum(item.attempts for item in items),\n            "input_tokens": sum(item.input_tokens for item in items),\n            "output_tokens": sum(item.output_tokens for item in items),\n            "cache_creation_input_tokens": sum(item.cache_creation_input_tokens for item in items),\n            "cache_read_input_tokens": sum(item.cache_read_input_tokens for item in items),\n            "total_tokens": sum(item.total_tokens for item in items),\n            "provider_latency_ms": round(sum(item.provider_latency_ms for item in items), 3),\n        }\n'''
    new_summary = '''    def summary(items: list[TaskOutcome]) -> dict[str, Any]:\n        passed = sum(item.passed for item in items)\n        input_tokens = sum(item.input_tokens for item in items)\n        output_tokens = sum(item.output_tokens for item in items)\n        cache_creation = sum(item.cache_creation_input_tokens for item in items)\n        cache_read = sum(item.cache_read_input_tokens for item in items)\n        total_tokens = input_tokens + output_tokens + cache_creation + cache_read\n        estimated_cost = None\n        if (\n            config.pricing_input_usd_per_million is not None\n            and config.pricing_output_usd_per_million is not None\n        ):\n            estimated_cost = (\n                (input_tokens + cache_creation + cache_read)\n                * config.pricing_input_usd_per_million\n                / 1_000_000\n                + output_tokens\n                * config.pricing_output_usd_per_million\n                / 1_000_000\n            )\n        return {\n            "observations": len(items),\n            "passed": passed,\n            "pass_rate": passed / len(items),\n            "attempts": sum(item.attempts for item in items),\n            "input_tokens": input_tokens,\n            "output_tokens": output_tokens,\n            "cache_creation_input_tokens": cache_creation,\n            "cache_read_input_tokens": cache_read,\n            "total_tokens": total_tokens,\n            "tokens_per_passed_task": total_tokens / passed if passed else None,\n            "attempts_per_passed_task": sum(item.attempts for item in items) / passed if passed else None,\n            "estimated_cost_usd": estimated_cost,\n            "cost_per_passed_task_usd": estimated_cost / passed if estimated_cost is not None and passed else None,\n            "provider_latency_ms": round(sum(item.provider_latency_ms for item in items), 3),\n        }\n'''
    replace_once(path, old_summary, new_summary)
    replace_once(
        path,
        '    token_gate = reduction_ci[0] >= config.target_token_reduction\n',
        '    swarm_summary = summary(swarm)\n'
        '    baseline_summary = summary(baseline)\n'
        '    token_per_pass_reduction = (\n'
        '        1.0 - swarm_summary["tokens_per_passed_task"] / baseline_summary["tokens_per_passed_task"]\n'
        '        if swarm_summary["tokens_per_passed_task"] is not None\n'
        '        and baseline_summary["tokens_per_passed_task"]\n'
        '        else None\n'
        '    )\n'
        '    cost_per_pass_reduction = (\n'
        '        1.0 - swarm_summary["cost_per_passed_task_usd"] / baseline_summary["cost_per_passed_task_usd"]\n'
        '        if swarm_summary["cost_per_passed_task_usd"] is not None\n'
        '        and baseline_summary["cost_per_passed_task_usd"]\n'
        '        else None\n'
        '    )\n\n'
        '    token_gate = reduction_ci[0] >= config.target_token_reduction\n',
    )
    replace_once(path, '        "swarm": summary(swarm),\n        "baseline": summary(baseline),\n', '        "swarm": swarm_summary,\n        "baseline": baseline_summary,\n')
    replace_once(
        path,
        '        "quality_pass_rate_delta": quality_delta,\n',
        '        "quality_pass_rate_delta": quality_delta,\n'
        '        "token_per_passed_task_reduction": token_per_pass_reduction,\n'
        '        "cost_per_passed_task_reduction": cost_per_pass_reduction,\n',
    )
    replace_once(
        path,
        '    pct = lambda value: f"{value * 100:.2f}%"\n',
        '    pct = lambda value: f"{value * 100:.2f}%"\n'
        '    pct_optional = lambda value: "n/a" if value is None else pct(value)\n'
        '    fmt = lambda value, digits=2: "n/a" if value is None else format(value, f".{digits}f")\n',
    )
    replace_once(
        path,
        '| Total provider tokens | {sw[\'total_tokens\']} | {base[\'total_tokens\']} |\n',
        '| Total provider tokens | {sw[\'total_tokens\']} | {base[\'total_tokens\']} |\n'
        '| Tokens per passed task | {fmt(sw[\'tokens_per_passed_task\'])} | {fmt(base[\'tokens_per_passed_task\'])} |\n'
        '| Estimated provider cost (USD) | {fmt(sw[\'estimated_cost_usd\'], 4)} | {fmt(base[\'estimated_cost_usd\'], 4)} |\n'
        '| Cost per passed task (USD) | {fmt(sw[\'cost_per_passed_task_usd\'], 6)} | {fmt(base[\'cost_per_passed_task_usd\'], 6)} |\n',
    )
    replace_once(
        path,
        '- Pass-rate difference (SWARM − baseline): **{pct(report[\'quality_pass_rate_delta\'])}**\n',
        '- Pass-rate difference (SWARM − baseline): **{pct(report[\'quality_pass_rate_delta\'])}**\n'
        '- Token reduction per passed task: **{pct_optional(report[\'token_per_passed_task_reduction\'])}**\n'
        '- Cost reduction per passed task: **{pct_optional(report[\'cost_per_passed_task_reduction\'])}**\n',
    )


def main() -> None:
    patch_protocol()
    patch_controller()
    patch_runner()
    patch_analysis()
    print("Applied related-projects pilot patch")


if __name__ == "__main__":
    main()
