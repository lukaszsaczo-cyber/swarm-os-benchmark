"""Run three paired, synthetic 10x10 simulations of memory-cycle v4.

This is an engineering simulation, not empirical Claude evidence.
"""
from __future__ import annotations

import json
import random
import shutil
from pathlib import Path

from swarm_validation.evaluator import Evaluation
from swarm_validation.models import ProviderResponse, Usage
from swarm_validation.protocol import ProtocolConfig
from swarm_validation.runner import BenchmarkRunner


class PairedSyntheticProvider:
    def __init__(self, seed: int) -> None:
        self.seed = seed
        self.calls: list[dict[str, object]] = []

    def generate(self, *, model, system, messages, max_tokens, temperature, metadata=None):
        task_id = str(metadata["task_id"])
        attempt = int(metadata["attempt"])
        condition = str(metadata["condition"])
        memory = "Prior-cycle intuition" in system
        probability = 0.84 if condition == "swarm" and memory else 0.72
        probability = min(0.96, probability + 0.12 * (attempt - 1))
        latent = random.Random(f"{self.seed}:{task_id}:{attempt}").random()
        passed = latent < probability
        expected = int(task_id.split("/")[-1])
        text = f"    return {expected if passed else expected + 1}\n"
        chars = len(system) + sum(len(item["content"]) for item in messages)
        usage = Usage(input_tokens=55 + chars // 4, output_tokens=8)
        self.calls.append({"condition": condition, "attempt": attempt, "memory": memory})
        return ProviderResponse(text, usage, model, "end_turn", 1.0, f"synthetic-{len(self.calls)}")


def fast_evaluate(task, completion, config=None):
    expected = int(task.task_id.split("/")[-1])
    passed = f"return {expected}" in completion
    return Evaluation(passed, "passed" if passed else "failed", 0.1, 0 if passed else 1, "", "" if passed else "AssertionError")


def write_tasks(path: Path) -> None:
    with path.open("w", encoding="utf-8") as handle:
        for index in range(160):
            handle.write(json.dumps({
                "task_id": f"t/{index}",
                "prompt": f'def value_{index}():\n    """sequence list sum aggregate values; return integer {index}."""\n',
                "test": f"def check(candidate):\n    assert candidate() == {index}",
                "entry_point": f"value_{index}",
            }) + "\n")


def main() -> None:
    root = Path(__file__).resolve().parents[1] / "results" / "memory-cycle-v4-synthetic"
    rows = []
    for seed in (101, 202, 303):
        output = root / f"run-{seed}"
        shutil.rmtree(output, ignore_errors=True)
        output.mkdir(parents=True)
        tasks = output / "tasks.jsonl"
        write_tasks(tasks)
        provider = PairedSyntheticProvider(seed)
        config = ProtocolConfig(bootstrap_samples=2000, cycle_length=8)
        report = BenchmarkRunner(
            config=config,
            provider=provider,
            tasks_path=tasks,
            output_dir=output / "results",
            evaluator_fn=fast_evaluate,
        ).run()
        rows.append({
            "seed": seed,
            "report": report,
            "memory_calls": sum(bool(call["memory"]) for call in provider.calls if call["condition"] == "swarm"),
            "retry_memory_calls": sum(bool(call["memory"]) for call in provider.calls if call["condition"] == "swarm" and call["attempt"] != 1),
        })
    print(json.dumps(rows, indent=2))


if __name__ == "__main__":
    main()
