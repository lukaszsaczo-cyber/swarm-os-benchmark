# THREE FINAL TEST RUNS

## Run 1
```text
test_analysis_confirmed_at_25_percent (test_core.CoreTests.test_analysis_confirmed_at_25_percent) ... ok
test_analysis_rejects_ten_percent (test_core.CoreTests.test_analysis_rejects_ten_percent) ... ok
test_assignment_is_disjoint_and_paired (test_core.CoreTests.test_assignment_is_disjoint_and_paired) ... ok
test_end_to_end_10x10_fake_provider (test_core.CoreTests.test_end_to_end_10x10_fake_provider) ... ok
test_evaluator_pass_and_fail (test_core.CoreTests.test_evaluator_pass_and_fail) ... ok
test_final_protocol_has_160_pairs_and_960_max_calls (test_core.CoreTests.test_final_protocol_has_160_pairs_and_960_max_calls) ... ok
test_normalize_full_function (test_core.CoreTests.test_normalize_full_function) ... ok
test_resume_after_interruption_between_conditions (test_core.CoreTests.test_resume_after_interruption_between_conditions) ... ok
test_sonnet5_uses_default_sampling (test_core.CoreTests.test_sonnet5_uses_default_sampling) ... ok
test_swarm_memory_is_created_only_after_crossing_40 (test_core.CoreTests.test_swarm_memory_is_created_only_after_crossing_40) ... ok
test_40_is_threshold_and_reset_occurs_only_on_next_cycle (test_cycle_memory.CycleMemoryTests.test_40_is_threshold_and_reset_occurs_only_on_next_cycle) ... ok
test_all_failure_cycle_creates_no_intuitive_memory (test_cycle_memory.CycleMemoryTests.test_all_failure_cycle_creates_no_intuitive_memory) ... ok
test_failures_are_destroyed_at_6 (test_cycle_memory.CycleMemoryTests.test_failures_are_destroyed_at_6) ... ok
test_irrelevant_intuitive_memory_is_rejected (test_cycle_memory.CycleMemoryTests.test_irrelevant_intuitive_memory_is_rejected) ... ok
test_memory_not_used_inside_same_cycle (test_cycle_memory.CycleMemoryTests.test_memory_not_used_inside_same_cycle) ... ok
test_raw_code_never_becomes_intuitive_memory (test_cycle_memory.CycleMemoryTests.test_raw_code_never_becomes_intuitive_memory) ... ok
test_relevant_intuitive_memory_is_used_after_crossing_40 (test_cycle_memory.CycleMemoryTests.test_relevant_intuitive_memory_is_used_after_crossing_40) ... ok
test_retry_drops_memory_but_keeps_feedback (test_cycle_memory.CycleMemoryTests.test_retry_drops_memory_but_keeps_feedback) ... ok
test_success_increases_fuel_failure_decreases_fuel (test_cycle_memory.CycleMemoryTests.test_success_increases_fuel_failure_decreases_fuel) ... ok

----------------------------------------------------------------------
Ran 19 tests in 2.102s

OK
```

## Run 2
```text
test_analysis_confirmed_at_25_percent (test_core.CoreTests.test_analysis_confirmed_at_25_percent) ... ok
test_analysis_rejects_ten_percent (test_core.CoreTests.test_analysis_rejects_ten_percent) ... ok
test_assignment_is_disjoint_and_paired (test_core.CoreTests.test_assignment_is_disjoint_and_paired) ... ok
test_end_to_end_10x10_fake_provider (test_core.CoreTests.test_end_to_end_10x10_fake_provider) ... ok
test_evaluator_pass_and_fail (test_core.CoreTests.test_evaluator_pass_and_fail) ... ok
test_final_protocol_has_160_pairs_and_960_max_calls (test_core.CoreTests.test_final_protocol_has_160_pairs_and_960_max_calls) ... ok
test_normalize_full_function (test_core.CoreTests.test_normalize_full_function) ... ok
test_resume_after_interruption_between_conditions (test_core.CoreTests.test_resume_after_interruption_between_conditions) ... ok
test_sonnet5_uses_default_sampling (test_core.CoreTests.test_sonnet5_uses_default_sampling) ... ok
test_swarm_memory_is_created_only_after_crossing_40 (test_core.CoreTests.test_swarm_memory_is_created_only_after_crossing_40) ... ok
test_40_is_threshold_and_reset_occurs_only_on_next_cycle (test_cycle_memory.CycleMemoryTests.test_40_is_threshold_and_reset_occurs_only_on_next_cycle) ... ok
test_all_failure_cycle_creates_no_intuitive_memory (test_cycle_memory.CycleMemoryTests.test_all_failure_cycle_creates_no_intuitive_memory) ... ok
test_failures_are_destroyed_at_6 (test_cycle_memory.CycleMemoryTests.test_failures_are_destroyed_at_6) ... ok
test_irrelevant_intuitive_memory_is_rejected (test_cycle_memory.CycleMemoryTests.test_irrelevant_intuitive_memory_is_rejected) ... ok
test_memory_not_used_inside_same_cycle (test_cycle_memory.CycleMemoryTests.test_memory_not_used_inside_same_cycle) ... ok
test_raw_code_never_becomes_intuitive_memory (test_cycle_memory.CycleMemoryTests.test_raw_code_never_becomes_intuitive_memory) ... ok
test_relevant_intuitive_memory_is_used_after_crossing_40 (test_cycle_memory.CycleMemoryTests.test_relevant_intuitive_memory_is_used_after_crossing_40) ... ok
test_retry_drops_memory_but_keeps_feedback (test_cycle_memory.CycleMemoryTests.test_retry_drops_memory_but_keeps_feedback) ... ok
test_success_increases_fuel_failure_decreases_fuel (test_cycle_memory.CycleMemoryTests.test_success_increases_fuel_failure_decreases_fuel) ... ok

----------------------------------------------------------------------
Ran 19 tests in 1.952s

OK
```

## Run 3
```text
test_analysis_confirmed_at_25_percent (test_core.CoreTests.test_analysis_confirmed_at_25_percent) ... ok
test_analysis_rejects_ten_percent (test_core.CoreTests.test_analysis_rejects_ten_percent) ... ok
test_assignment_is_disjoint_and_paired (test_core.CoreTests.test_assignment_is_disjoint_and_paired) ... ok
test_end_to_end_10x10_fake_provider (test_core.CoreTests.test_end_to_end_10x10_fake_provider) ... ok
test_evaluator_pass_and_fail (test_core.CoreTests.test_evaluator_pass_and_fail) ... ok
test_final_protocol_has_160_pairs_and_960_max_calls (test_core.CoreTests.test_final_protocol_has_160_pairs_and_960_max_calls) ... ok
test_normalize_full_function (test_core.CoreTests.test_normalize_full_function) ... ok
test_resume_after_interruption_between_conditions (test_core.CoreTests.test_resume_after_interruption_between_conditions) ... ok
test_sonnet5_uses_default_sampling (test_core.CoreTests.test_sonnet5_uses_default_sampling) ... ok
test_swarm_memory_is_created_only_after_crossing_40 (test_core.CoreTests.test_swarm_memory_is_created_only_after_crossing_40) ... ok
test_40_is_threshold_and_reset_occurs_only_on_next_cycle (test_cycle_memory.CycleMemoryTests.test_40_is_threshold_and_reset_occurs_only_on_next_cycle) ... ok
test_all_failure_cycle_creates_no_intuitive_memory (test_cycle_memory.CycleMemoryTests.test_all_failure_cycle_creates_no_intuitive_memory) ... ok
test_failures_are_destroyed_at_6 (test_cycle_memory.CycleMemoryTests.test_failures_are_destroyed_at_6) ... ok
test_irrelevant_intuitive_memory_is_rejected (test_cycle_memory.CycleMemoryTests.test_irrelevant_intuitive_memory_is_rejected) ... ok
test_memory_not_used_inside_same_cycle (test_cycle_memory.CycleMemoryTests.test_memory_not_used_inside_same_cycle) ... ok
test_raw_code_never_becomes_intuitive_memory (test_cycle_memory.CycleMemoryTests.test_raw_code_never_becomes_intuitive_memory) ... ok
test_relevant_intuitive_memory_is_used_after_crossing_40 (test_cycle_memory.CycleMemoryTests.test_relevant_intuitive_memory_is_used_after_crossing_40) ... ok
test_retry_drops_memory_but_keeps_feedback (test_cycle_memory.CycleMemoryTests.test_retry_drops_memory_but_keeps_feedback) ... ok
test_success_increases_fuel_failure_decreases_fuel (test_cycle_memory.CycleMemoryTests.test_success_increases_fuel_failure_decreases_fuel) ... ok

----------------------------------------------------------------------
Ran 19 tests in 2.075s

OK
```

