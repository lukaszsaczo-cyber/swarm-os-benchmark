# Triple paired offline simulation

**Important:** this is an engineering simulation using a synthetic provider and assumed probabilities. It is not a new Claude API validation and cannot confirm the 20% claim.

Each run contains 10 SWARM agents, 10 baseline agents and 160 tasks per condition. Both conditions receive the same latent random difficulty for each task/attempt.

| Seed | SWARM pass | Baseline pass | SWARM attempts | Baseline attempts | SWARM tokens | Baseline tokens | Reduction | 95% CI | Verdict |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| 101 | 160/160 | 160/160 | 201 | 213 | 42014 | 42956 | 2.19% | -1.19% to 5.36% | NOT_CONFIRMED |
| 202 | 160/160 | 160/160 | 207 | 223 | 43378 | 45349 | 4.35% | 0.64% to 7.97% | NOT_CONFIRMED |
| 303 | 160/160 | 160/160 | 188 | 200 | 38738 | 39724 | 2.48% | -2.52% to 8.84% | NOT_CONFIRMED |

Mean point reduction across the three synthetic runs: **3.01%**.

All three runs preserved quality and used intuitive memory only on first attempts. None met the preregistered 20% gate. The simulation supports structural correctness and modest possible efficiency, not empirical superiority.
