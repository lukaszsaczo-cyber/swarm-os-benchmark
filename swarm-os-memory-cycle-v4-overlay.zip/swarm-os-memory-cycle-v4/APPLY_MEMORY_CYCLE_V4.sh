#!/usr/bin/env bash
set -euo pipefail

if [[ ! -d .git || ! -d validation_10x10 ]]; then
  echo "Run this script from the root of swarm-os-benchmark." >&2
  exit 1
fi

BRANCH="agent/memory-cycle-v4"
git switch -c "$BRANCH"
cp -a "$(dirname "$0")/github_overlay/." .

cd validation_10x10
python -m compileall -q swarm_validation scripts
for n in 1 2 3; do
  echo "=== TEST RUN $n ==="
  python -m unittest discover -s swarm_validation/tests -v
done
python scripts/triple_cycle_simulation.py > memory_cycle_v4_simulation.json
cd ..

git add validation_10x10/swarm_validation validation_10x10/scripts/triple_cycle_simulation.py validation_10x10/examples/memory_cycle_v4_pilot.json validation_10x10/MEMORY_CYCLE_V4.md
git commit -m "Fix SWARM memory cycle through state 40"
git push -u origin "$BRANCH"

gh pr create --draft --base main --head "$BRANCH" \
  --title "Fix SWARM memory cycle through state 40" \
  --body "Implements working, transient-feedback and intuitive memory separation; ROZPAD II -> 3 -> 6 -> 28 -> 40 -> new-cycle transition; full failure purge; relevance-gated compact recall; retry memory removal; corrected fuel direction; three-run tests and synthetic simulations. The historical NOT_CONFIRMED result and preregistered protocol remain unchanged."
