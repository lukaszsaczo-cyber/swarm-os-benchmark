# Frozen experimental protocol — v1.1.0

## Primary question

Does the allowed cross-task memory policy improve first-attempt correctness or reduce real token/cost usage compared with a stateless baseline using the same model and execution budget?

## Variants

### Stateless

- Fresh agent state for every task.
- Same system instruction, task prompt, repair budget, and sanitized retry feedback.
- No cross-task memory.

### Stateful

- Fresh memory at the beginning of each run.
- Generalized cross-task lessons persist between tasks.
- Memory is frozen during all attempts on one task and updated only after that task ends.
- No prior code, answer, private test, assertion value, task-answer mapping, or full completion may be stored.

## Pairing and order

- One selected task set is shared by both variants.
- Both variants receive the same task order within a run.
- Run order is counterbalanced: odd runs execute stateless first; even runs execute stateful first.
- Task selection and task order use separately recorded seeds.

## Retry feedback

Later attempts may receive only one broad category such as syntax error, type error, timeout, index error, or private-test failure. Raw traceback lines, assertion expressions, expected values, and test code are not returned to the model.

## Primary metrics

- `pass_at_1`
- real input tokens
- real cached-input tokens
- real output tokens
- real reasoning tokens when reported
- real total tokens
- cost when a complete price table is provided

## Secondary metrics

- `success_within_budget`
- attempts to first success
- latency
- failure categories

## Non-claims

`success_within_budget` is not standard `pass@k`. Standard HumanEval `pass@k` requires independent samples and a separate estimator.

## Security

- Real API code must run in Docker with network disabled, read-only root filesystem, dropped capabilities, no-new-privileges, resource limits, and a hard timeout.
- The in-process trusted runner is allowed only for the hard-coded mock provider.
- The local subprocess runner is development-only and is not a security boundary.

## Stopping and versioning

- The protocol and memory policy are frozen before a paid run.
- Any material change to prompting, memory, task selection, retry feedback, model, or sandbox creates a new experiment version.
- Failed, zero, or negative stateful results are retained and reported.
