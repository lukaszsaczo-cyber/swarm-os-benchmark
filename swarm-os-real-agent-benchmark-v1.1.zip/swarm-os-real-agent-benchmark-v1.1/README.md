# SWARM_OS Real Agent Benchmark v1.1

A reproducible harness for testing whether a stateful coding agent actually improves quality or cost relative to a stateless baseline when both use the same real model API, task set, order, attempt budget, and sandbox.

## Status

- Mock end-to-end validation: complete.
- Real API provider: implemented.
- Docker isolation: implemented.
- Paid pilot: not yet executed.
- No real-world savings claim has been established.

## Critical methodology

This project reports two different metrics:

- `pass_at_1`: success on the first generated solution.
- `success_within_budget`: success after iterative repair within the configured attempt budget.

`success_within_budget` is **not** standard HumanEval `pass@k`, because later attempts receive sanitized failure-category feedback.

## Fairness controls in v1.1

- Identical selected tasks and order seeds for both variants.
- Variant execution order is counterbalanced across runs.
- Stateful memory is frozen during retries and updated only after a task finishes.
- Retry feedback contains only a broad error category; private assertion text and traceback source lines are never sent back to the model.
- JSONL stores candidate code only. Private test code is excluded and the complete execution source is represented only by SHA-256.
- Input, cached-input, output, reasoning, and total token usage are recorded separately.
- Cost is `null` unless all required price variables are supplied; missing prices are never reported as zero cost.
- Every run writes an experiment manifest with selected task IDs, seeds, model, sandbox, harness version, and memory-policy version.

## Free deterministic verification

```bash
python -m pip install -e '.[dev]'
pytest
python -m realbench.cli \
  --provider mock \
  --dataset pilot \
  --task-limit 10 \
  --runs 2 \
  --max-attempts 3 \
  --sandbox trusted
```

Outputs:

```text
results/experiment_manifest.json
results/raw_results.jsonl
results/summary.json
```

## Real OpenAI pilot

Never commit an API key. Set it as an environment variable or GitHub Actions secret.

```bash
export OPENAI_API_KEY="..."
export OPENAI_MODEL="EXPLICIT_MODEL_ID"
export OPENAI_INPUT_USD_PER_MILLION="..."
export OPENAI_CACHED_INPUT_USD_PER_MILLION="..."
export OPENAI_OUTPUT_USD_PER_MILLION="..."

python -m pip install -e '.[openai,dev]'
python -m realbench.cli \
  --provider openai \
  --dataset pilot \
  --task-limit 10 \
  --runs 2 \
  --max-attempts 3 \
  --sandbox docker
```

The OpenAI provider uses the Responses API, sets `store=False`, and records usage fields returned by the API. Copy current prices immediately before each experiment rather than committing prices to source control.

## HumanEval pilot

```bash
python -m pip install -e '.[openai,humaneval,dev]'
python -m realbench.cli \
  --provider openai \
  --dataset humaneval \
  --task-limit 10 \
  --selection-seed 20260731 \
  --runs 2 \
  --max-attempts 3 \
  --sandbox docker
```

Generated code is untrusted. Do not use `trusted` or `local` with API output.

## Frozen memory policy v1.1.0

Allowed:

- short general rules,
- deterministic error categories,
- aggregate strategy counters.

Forbidden:

- previous generated code,
- task answers,
- private tests or assertion values,
- task IDs linked to solutions,
- executable snippets,
- full prompts or completions.

A memory-policy change creates a new experiment version.

## Repository structure

```text
realbench/                  harness package
realbench/providers/        mock and OpenAI providers
tests/                      automated checks
.github/workflows/          CI and manual paid-pilot workflow
config/                     example experiment configuration
PROTOCOL.md                 frozen experimental protocol
VERIFICATION.md             local verification record
```

## Interpretation rule

A stateful advantage is accepted only if it appears in real sandboxed API runs with raw data, paired analysis, repeated runs, and no private-test leakage. A negative or zero result is a valid falsification outcome.
