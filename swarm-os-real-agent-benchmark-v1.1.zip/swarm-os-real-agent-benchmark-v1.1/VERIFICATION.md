# Local verification record

Date: 2026-07-31
Harness: 0.2.0
Memory policy: 1.1.0

## Commands

```bash
PYTHONPATH=. pytest -q
PYTHONPATH=. python -m realbench.cli \
  --provider mock \
  --dataset pilot \
  --task-limit 10 \
  --runs 2 \
  --max-attempts 3 \
  --sandbox trusted \
  --output-dir results
```

## Results

- Automated tests: 11 passed.
- Raw task-run records: 40.
- Complete stateless/stateful pairs: 20.
- Both mock variants: 100% first-attempt success.
- Stateless: 1,818 mock input tokens and 580 mock output tokens.
- Stateful: 2,618 mock input tokens and 580 mock output tokens.
- Paired stateful overhead: +800 mock input tokens.

The mock run validates control flow, pairing, counterbalancing, memory boundaries, private-test protection, JSONL logging, token fields, and reporting. It does not establish a quality or cost advantage.

## Corrections made before a paid run

1. Candidate code is now stored separately from private executable tests.
2. Raw hidden-test tracebacks are not sent back to the model.
3. Persistent memory does not change between retries of the same task.
4. Variant order is counterbalanced across runs.
5. Cached-input and reasoning-token details are recorded.
6. Unknown prices produce `null` cost rather than false zero cost.
7. HumanEval subsets are deterministically sampled and recorded in a manifest.
8. Local resource limits and Docker hardening were strengthened.

## Unexecuted gate

A real API call and Docker execution were not performed in this environment because no API key was supplied and Docker is unavailable here. The GitHub Actions workflow is the intended execution path for the first paid pilot.
