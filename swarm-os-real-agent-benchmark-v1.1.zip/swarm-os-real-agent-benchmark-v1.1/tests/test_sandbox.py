from realbench.sandbox import LocalPythonSandbox


def test_local_sandbox_pass_and_fail():
    sandbox = LocalPythonSandbox(timeout_seconds=3.0)
    assert sandbox.run("assert 2 + 2 == 4\n").passed
    failed = sandbox.run("assert 2 + 2 == 5\n")
    assert not failed.passed
    assert failed.status == "failed"


def test_local_sandbox_timeout():
    sandbox = LocalPythonSandbox(timeout_seconds=0.2)
    result = sandbox.run("while True:\n    pass\n")
    assert result.status == "timeout"
