from realbench.memory import sanitize_rule, update_memory_after_task
from realbench.schemas import ExecutionResult, MemoryState


def test_sanitizer_rejects_code_and_task_ids():
    assert sanitize_rule("def solve(x): return x") is None
    assert sanitize_rule("Remember HumanEval/0 answer") is None
    assert sanitize_rule("Check boundaries and empty inputs.") == "Check boundaries and empty inputs."


def test_memory_updates_once_per_task_but_keeps_failure_categories():
    failed = ExecutionResult(False, "failed", "", "AssertionError: secret value 123", 1.0, 1)
    passed = ExecutionResult(True, "passed", "", "", 1.0, 0)
    memory = update_memory_after_task(MemoryState(), [failed, passed])
    assert memory.strategy_stats["tasks_seen"] == 1
    assert memory.strategy_stats["tasks_passed"] == 1
    assert memory.strategy_stats["test_failure"] == 1
    assert memory.error_patterns[0]["category"] == "test_failure"
    assert "123" not in str(memory.to_dict())
