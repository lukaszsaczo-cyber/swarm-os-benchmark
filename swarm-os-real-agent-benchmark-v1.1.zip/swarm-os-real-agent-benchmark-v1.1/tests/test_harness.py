import json
from pathlib import Path

from realbench.agents import CodingAgent
from realbench.cli import variant_order
from realbench.datasets import pilot_tasks
from realbench.harness import run_variant, select_tasks
from realbench.providers import MockProvider
from realbench.report import write_report
from realbench.sandbox import TrustedPythonSandbox


def test_mock_end_to_end_and_fair_order(tmp_path: Path):
    tasks = pilot_tasks()[:4]
    output = tmp_path / "raw.jsonl"
    sandbox = TrustedPythonSandbox()
    provider = MockProvider()

    stateless = run_variant(
        tasks=tasks,
        agent=CodingAgent(provider, stateful=False, max_attempts=2),
        sandbox=sandbox,
        run_id=1,
        order_seed=77,
        output_path=output,
    )
    stateful = run_variant(
        tasks=tasks,
        agent=CodingAgent(provider, stateful=True, max_attempts=2),
        sandbox=sandbox,
        run_id=1,
        order_seed=77,
        output_path=output,
    )

    assert [row.task_id for row in stateless] == [row.task_id for row in stateful]
    assert all(row.passed for row in stateless + stateful)
    assert stateful[-1].memory_after["strategy_stats"]["tasks_seen"] == 4
    assert stateless[-1].memory_after["strategy_stats"] == {}

    report = write_report(output, tmp_path / "summary.json")
    assert report["variants"]["stateless"]["pass_at_1"] == 1.0
    assert report["variants"]["stateful"]["pass_at_1"] == 1.0
    assert report["paired"]["pairs"] == 4
    assert json.loads((tmp_path / "summary.json").read_text())["variants"]["stateful"]["task_runs"] == 4


def test_variant_order_is_counterbalanced():
    assert variant_order(1) == (False, True)
    assert variant_order(2) == (True, False)


def test_selection_is_deterministic_and_preserves_dataset_order():
    tasks = pilot_tasks()
    first = select_tasks(tasks, 4, 123)
    second = select_tasks(tasks, 4, 123)
    assert [task.task_id for task in first] == [task.task_id for task in second]
    assert len(first) == 4
