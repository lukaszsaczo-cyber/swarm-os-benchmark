from types import SimpleNamespace

from realbench.providers.openai_provider import OpenAIProvider


class FakeResponses:
    def create(self, **kwargs):
        assert kwargs["store"] is False
        usage = SimpleNamespace(
            input_tokens=100,
            output_tokens=40,
            total_tokens=140,
            input_tokens_details=SimpleNamespace(cached_tokens=20),
            output_tokens_details=SimpleNamespace(reasoning_tokens=10),
        )
        return SimpleNamespace(output_text="def f():\n    return 1\n", usage=usage, id="resp_test")


class FakeClient:
    responses = FakeResponses()


def test_openai_usage_and_cached_cost_accounting():
    provider = object.__new__(OpenAIProvider)
    provider.client = FakeClient()
    provider.model = "test-model"
    provider.max_output_tokens = 100
    provider.input_rate = 2.0
    provider.cached_input_rate = 0.5
    provider.output_rate = 8.0

    response = provider.generate(system_prompt="s", user_prompt="u")
    assert response.input_tokens == 100
    assert response.cached_input_tokens == 20
    assert response.output_tokens == 40
    assert response.reasoning_tokens == 10
    assert response.total_tokens == 140
    expected = (80 * 2.0 + 20 * 0.5 + 40 * 8.0) / 1_000_000
    assert response.cost_usd == expected


def test_cost_is_unknown_when_cached_rate_missing():
    provider = object.__new__(OpenAIProvider)
    provider.client = FakeClient()
    provider.model = "test-model"
    provider.max_output_tokens = 100
    provider.input_rate = 2.0
    provider.cached_input_rate = None
    provider.output_rate = 8.0
    assert provider.generate(system_prompt="s", user_prompt="u").cost_usd is None
