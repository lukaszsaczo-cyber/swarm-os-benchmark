from pathlib import Path

from realbench.agents import CodingAgent, sanitized_feedback
from realbench.datasets import pilot_tasks
from realbench.harness import run_variant
from realbench.providers import MockProvider
from realbench.schemas import ExecutionResult
from realbench.sandbox import TrustedPythonSandbox


def test_retry_feedback_never_exposes_private_assertion_text():
    result = ExecutionResult(
        passed=False,
        status="failed",
        stdout="",
        stderr='Traceback: assert candidate(7) == 12345\nAssertionError',
        duration_ms=1.0,
        return_code=1,
    )
    feedback = sanitized_feedback(result)
    assert "12345" not in feedback
    assert "candidate(7)" not in feedback
    assert "private tests failed" in feedback


def test_jsonl_stores_candidate_not_private_tests(tmp_path: Path):
    task = pilot_tasks()[0]
    output = tmp_path / "raw.jsonl"
    records = run_variant(
        tasks=[task],
        agent=CodingAgent(MockProvider(), stateful=False, max_attempts=1),
        sandbox=TrustedPythonSandbox(),
        run_id=1,
        order_seed=1,
        output_path=output,
    )
    generated = records[0].attempt_records[0].generated_code
    assert "assert add(2, 3)" not in generated
    assert "def add" in generated
    assert len(records[0].attempt_records[0].execution_source_sha256) == 64
