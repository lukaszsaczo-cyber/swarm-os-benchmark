from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Literal


@dataclass(frozen=True)
class TaskSpec:
    task_id: str
    model_prompt: str
    code_prefix: str
    tests: str
    check_call: str = ""
    entry_point: str = ""


@dataclass(frozen=True)
class ProviderResponse:
    text: str
    input_tokens: int
    output_tokens: int
    latency_ms: float
    model: str
    request_id: str = ""
    cached_input_tokens: int = 0
    reasoning_tokens: int = 0
    total_tokens: int = 0
    cost_usd: float | None = None


@dataclass(frozen=True)
class ExecutionResult:
    passed: bool
    status: Literal["passed", "failed", "timeout", "sandbox_error"]
    stdout: str
    stderr: str
    duration_ms: float
    return_code: int | None


@dataclass
class MemoryState:
    policy_version: str = "1.1.0"
    general_rules: list[str] = field(default_factory=list)
    error_patterns: list[dict[str, str]] = field(default_factory=list)
    strategy_stats: dict[str, int] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class AttemptRecord:
    attempt: int
    generated_code: str
    execution_source_sha256: str
    passed: bool
    execution_status: str
    stdout: str
    stderr: str
    tokens_input: int
    tokens_output: int
    cached_input_tokens: int
    reasoning_tokens: int
    total_tokens: int
    cost_usd: float | None
    latency_ms: float
    provider_model: str
    provider_request_id: str
    retry_reason: str = ""


@dataclass(frozen=True)
class TaskRunRecord:
    task_id: str
    variant: Literal["stateless", "stateful"]
    run_id: int
    order_seed: int
    order_index: int
    passed: bool
    passed_first_attempt: bool
    attempts: int
    tokens_input: int
    tokens_output: int
    cached_input_tokens: int
    reasoning_tokens: int
    total_tokens: int
    cost_usd: float | None
    latency_ms: float
    memory_before: dict[str, Any]
    memory_after: dict[str, Any]
    transitions_aq: list[str]
    attempt_records: list[AttemptRecord]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
