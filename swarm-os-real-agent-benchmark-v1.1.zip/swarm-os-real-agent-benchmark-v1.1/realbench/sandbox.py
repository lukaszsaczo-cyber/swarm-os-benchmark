from __future__ import annotations

import os
import shutil
import subprocess
import sys
import tempfile
import time
import uuid
from pathlib import Path

from .schemas import ExecutionResult


def _limit_resources(memory_mb: int, cpu_seconds: int) -> None:
    if os.name != "posix":
        return
    import resource

    memory_bytes = memory_mb * 1024 * 1024
    resource.setrlimit(resource.RLIMIT_AS, (memory_bytes, memory_bytes))
    resource.setrlimit(resource.RLIMIT_CPU, (cpu_seconds, cpu_seconds + 1))
    resource.setrlimit(resource.RLIMIT_NOFILE, (32, 32))
    resource.setrlimit(resource.RLIMIT_FSIZE, (1_048_576, 1_048_576))


class LocalPythonSandbox:
    """Development-only runner. Resource-limited, but not a hostile-code security boundary."""

    def __init__(self, timeout_seconds: float = 5.0, memory_mb: int = 512) -> None:
        self.timeout_seconds = timeout_seconds
        self.memory_mb = memory_mb

    def run(self, source: str) -> ExecutionResult:
        started = time.perf_counter()
        with tempfile.TemporaryDirectory(prefix="swarm-real-") as tmp:
            script = Path(tmp) / "candidate.py"
            script.write_text(source, encoding="utf-8")
            try:
                completed = subprocess.run(
                    [sys.executable, "-I", str(script)],
                    cwd=tmp,
                    capture_output=True,
                    text=True,
                    timeout=self.timeout_seconds,
                    env={"PYTHONHASHSEED": "0", "PATH": os.getenv("PATH", "")},
                    check=False,
                    preexec_fn=(
                        (lambda: _limit_resources(self.memory_mb, max(2, int(self.timeout_seconds * 3) + 1)))
                        if os.name == "posix"
                        else None
                    ),
                )
                duration = (time.perf_counter() - started) * 1000
                passed = completed.returncode == 0
                return ExecutionResult(
                    passed=passed,
                    status="passed" if passed else "failed",
                    stdout=completed.stdout[-8000:],
                    stderr=completed.stderr[-8000:],
                    duration_ms=duration,
                    return_code=completed.returncode,
                )
            except subprocess.TimeoutExpired as exc:
                duration = (time.perf_counter() - started) * 1000
                return ExecutionResult(
                    passed=False,
                    status="timeout",
                    stdout=(exc.stdout or "")[-8000:] if isinstance(exc.stdout, str) else "",
                    stderr=(exc.stderr or "")[-8000:] if isinstance(exc.stderr, str) else "",
                    duration_ms=duration,
                    return_code=None,
                )
            except Exception as exc:  # pragma: no cover
                duration = (time.perf_counter() - started) * 1000
                return ExecutionResult(
                    passed=False,
                    status="sandbox_error",
                    stdout="",
                    stderr=f"{type(exc).__name__}: {exc}",
                    duration_ms=duration,
                    return_code=None,
                )


class DockerPythonSandbox:
    """Runner for untrusted model code. Requires a working Docker daemon."""

    def __init__(self, image: str = "python:3.12-alpine", timeout_seconds: float = 8.0) -> None:
        self.image = image
        self.timeout_seconds = timeout_seconds
        if shutil.which("docker") is None:
            raise RuntimeError("Docker executable not found")

    def run(self, source: str) -> ExecutionResult:
        started = time.perf_counter()
        container_name = f"swarm-real-{uuid.uuid4().hex[:12]}"
        with tempfile.TemporaryDirectory(prefix="swarm-docker-") as tmp:
            script = Path(tmp) / "candidate.py"
            script.write_text(source, encoding="utf-8")
            command = [
                "docker", "run", "--rm", "--name", container_name,
                "--network=none",
                "--memory=256m", "--memory-swap=256m",
                "--cpus=0.5",
                "--pids-limit=64",
                "--ulimit", "nofile=64:64",
                "--ulimit", "nproc=64:64",
                "--read-only",
                "--user", "65534:65534",
                "--tmpfs", "/tmp:rw,noexec,nosuid,size=32m",
                "--cap-drop=ALL",
                "--security-opt", "no-new-privileges",
                "-v", f"{script}:/workspace/candidate.py:ro",
                self.image,
                "python", "-I", "/workspace/candidate.py",
            ]
            try:
                completed = subprocess.run(
                    command,
                    capture_output=True,
                    text=True,
                    timeout=self.timeout_seconds,
                    check=False,
                )
                duration = (time.perf_counter() - started) * 1000
                passed = completed.returncode == 0
                return ExecutionResult(
                    passed=passed,
                    status="passed" if passed else "failed",
                    stdout=completed.stdout[-8000:],
                    stderr=completed.stderr[-8000:],
                    duration_ms=duration,
                    return_code=completed.returncode,
                )
            except subprocess.TimeoutExpired:
                subprocess.run(
                    ["docker", "rm", "-f", container_name],
                    capture_output=True,
                    text=True,
                    timeout=5,
                    check=False,
                )
                duration = (time.perf_counter() - started) * 1000
                return ExecutionResult(False, "timeout", "", "", duration, None)
            except Exception as exc:  # pragma: no cover
                duration = (time.perf_counter() - started) * 1000
                return ExecutionResult(False, "sandbox_error", "", f"{type(exc).__name__}: {exc}", duration, None)


class TrustedPythonSandbox:
    """Fast in-process runner for the hard-coded MockProvider only. Never use with API output."""

    def run(self, source: str) -> ExecutionResult:
        import contextlib
        import io
        import traceback

        started = time.perf_counter()
        stdout_buffer = io.StringIO()
        stderr_buffer = io.StringIO()
        try:
            with contextlib.redirect_stdout(stdout_buffer), contextlib.redirect_stderr(stderr_buffer):
                exec(compile(source, "<trusted-mock>", "exec"), {"__name__": "__main__"})
            return ExecutionResult(
                passed=True,
                status="passed",
                stdout=stdout_buffer.getvalue()[-8000:],
                stderr=stderr_buffer.getvalue()[-8000:],
                duration_ms=(time.perf_counter() - started) * 1000,
                return_code=0,
            )
        except Exception:
            traceback.print_exc(file=stderr_buffer)
            return ExecutionResult(
                passed=False,
                status="failed",
                stdout=stdout_buffer.getvalue()[-8000:],
                stderr=stderr_buffer.getvalue()[-8000:],
                duration_ms=(time.perf_counter() - started) * 1000,
                return_code=1,
            )
