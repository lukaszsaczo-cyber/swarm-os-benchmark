from __future__ import annotations

from abc import ABC, abstractmethod

from realbench.schemas import ProviderResponse


class ModelProvider(ABC):
    @abstractmethod
    def generate(self, *, system_prompt: str, user_prompt: str) -> ProviderResponse:
        raise NotImplementedError
