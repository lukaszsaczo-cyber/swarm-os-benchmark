from __future__ import annotations

import os
import time

from realbench.schemas import ProviderResponse
from .base import ModelProvider


class OpenAIProvider(ModelProvider):
    """OpenAI Responses API provider with per-request usage accounting."""

    def __init__(
        self,
        model: str,
        *,
        max_output_tokens: int = 1200,
        input_usd_per_million: float | None = None,
        cached_input_usd_per_million: float | None = None,
        output_usd_per_million: float | None = None,
    ) -> None:
        try:
            from openai import OpenAI
        except (ImportError, AttributeError) as exc:
            raise RuntimeError("Install the OpenAI extra: pip install -e '.[openai]'") from exc

        self.client = OpenAI(max_retries=2, timeout=60.0)
        self.model = model
        self.max_output_tokens = max_output_tokens
        self.input_rate = input_usd_per_million
        self.cached_input_rate = cached_input_usd_per_million
        self.output_rate = output_usd_per_million

    @classmethod
    def from_env(cls, model: str | None = None) -> "OpenAIProvider":
        chosen_model = model or os.getenv("OPENAI_MODEL")
        if not chosen_model:
            raise RuntimeError("Set OPENAI_MODEL or pass --model with an explicit model ID")
        input_rate = os.getenv("OPENAI_INPUT_USD_PER_MILLION")
        cached_rate = os.getenv("OPENAI_CACHED_INPUT_USD_PER_MILLION")
        output_rate = os.getenv("OPENAI_OUTPUT_USD_PER_MILLION")
        return cls(
            chosen_model,
            input_usd_per_million=float(input_rate) if input_rate else None,
            cached_input_usd_per_million=float(cached_rate) if cached_rate else None,
            output_usd_per_million=float(output_rate) if output_rate else None,
        )

    def generate(self, *, system_prompt: str, user_prompt: str) -> ProviderResponse:
        started = time.perf_counter()
        response = self.client.responses.create(
            model=self.model,
            instructions=system_prompt,
            input=user_prompt,
            max_output_tokens=self.max_output_tokens,
            store=False,
        )
        latency_ms = (time.perf_counter() - started) * 1000
        usage = response.usage
        input_tokens = int(getattr(usage, "input_tokens", 0) or 0)
        output_tokens = int(getattr(usage, "output_tokens", 0) or 0)
        total_tokens = int(getattr(usage, "total_tokens", input_tokens + output_tokens) or 0)
        input_details = getattr(usage, "input_tokens_details", None)
        output_details = getattr(usage, "output_tokens_details", None)
        cached_input_tokens = int(getattr(input_details, "cached_tokens", 0) or 0)
        reasoning_tokens = int(getattr(output_details, "reasoning_tokens", 0) or 0)

        cost: float | None = None
        rates_complete = self.input_rate is not None and self.output_rate is not None
        if cached_input_tokens and self.cached_input_rate is None:
            rates_complete = False
        if rates_complete:
            uncached_input = max(0, input_tokens - cached_input_tokens)
            cost = uncached_input * self.input_rate / 1_000_000  # type: ignore[operator]
            if cached_input_tokens:
                cost += cached_input_tokens * self.cached_input_rate / 1_000_000  # type: ignore[operator]
            cost += output_tokens * self.output_rate / 1_000_000  # type: ignore[operator]

        return ProviderResponse(
            text=response.output_text,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cached_input_tokens=cached_input_tokens,
            reasoning_tokens=reasoning_tokens,
            total_tokens=total_tokens,
            latency_ms=latency_ms,
            model=self.model,
            request_id=response.id,
            cost_usd=cost,
        )
