from __future__ import annotations

import hashlib
import re
import time

from realbench.schemas import ProviderResponse
from .base import ModelProvider


_SOLUTIONS = {
    "pilot/add": "def add(a, b):\n    return a + b\n",
    "pilot/reverse_string": "def reverse_string(text):\n    return text[::-1]\n",
    "pilot/is_palindrome": "def is_palindrome(text):\n    return text == text[::-1]\n",
    "pilot/factorial": "def factorial(n):\n    if n < 0:\n        raise ValueError('n must be non-negative')\n    out = 1\n    for value in range(2, n + 1):\n        out *= value\n    return out\n",
    "pilot/fibonacci": "def fibonacci(n):\n    if n < 0:\n        raise ValueError('n must be non-negative')\n    a, b = 0, 1\n    for _ in range(n):\n        a, b = b, a + b\n    return a\n",
    "pilot/gcd": "def gcd(a, b):\n    a, b = abs(a), abs(b)\n    while b:\n        a, b = b, a % b\n    return a\n",
    "pilot/dedupe": "def dedupe(values):\n    seen = set()\n    out = []\n    for value in values:\n        if value not in seen:\n            seen.add(value)\n            out.append(value)\n    return out\n",
    "pilot/count_vowels": "def count_vowels(text):\n    return sum(char.lower() in 'aeiou' for char in text)\n",
    "pilot/flatten_one": "def flatten_one(items):\n    return [value for group in items for value in group]\n",
    "pilot/binary_search": "def binary_search(values, target):\n    lo, hi = 0, len(values) - 1\n    while lo <= hi:\n        mid = (lo + hi) // 2\n        if values[mid] == target:\n            return mid\n        if values[mid] < target:\n            lo = mid + 1\n        else:\n            hi = mid - 1\n    return -1\n",
}


class MockProvider(ModelProvider):
    model = "deterministic-mock-v1"

    def generate(self, *, system_prompt: str, user_prompt: str) -> ProviderResponse:
        started = time.perf_counter()
        match = re.search(r"TASK_ID:\s*([^\s]+)", user_prompt)
        task_id = match.group(1) if match else ""
        text = _SOLUTIONS.get(task_id, "raise NotImplementedError('unknown mock task')\n")
        input_tokens = max(1, (len(system_prompt) + len(user_prompt)) // 4)
        output_tokens = max(1, len(text) // 4)
        latency_ms = (time.perf_counter() - started) * 1000
        request_id = hashlib.sha256((task_id + system_prompt + user_prompt).encode()).hexdigest()[:16]
        return ProviderResponse(
            text=text,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            latency_ms=latency_ms,
            model=self.model,
            request_id=f"mock_{request_id}",
            cached_input_tokens=0,
            reasoning_tokens=0,
            total_tokens=input_tokens + output_tokens,
            cost_usd=0.0,
        )
