from __future__ import annotations

import re
from copy import deepcopy
from typing import Iterable

from .schemas import ExecutionResult, MemoryState

_FORBIDDEN = re.compile(
    r"```|\bdef\s+|\bclass\s+|\bassert\s+|\breturn\s+|HumanEval/|MBPP/|TASK_ID|entry_point",
    re.IGNORECASE,
)


def sanitize_rule(text: str, *, max_length: int = 220) -> str | None:
    """Allow only short, general natural-language lessons; reject code-like leakage."""
    normalized = " ".join(text.strip().split())
    if not normalized or len(normalized) > max_length:
        return None
    if _FORBIDDEN.search(normalized):
        return None
    return normalized


def render_memory(memory: MemoryState) -> str:
    rules = memory.general_rules[-12:]
    patterns = [item.get("lesson", "") for item in memory.error_patterns[-8:]]
    lines = [f"Memory policy version: {memory.policy_version}"]
    if rules:
        lines.append("General rules:")
        lines.extend(f"- {rule}" for rule in rules)
    if patterns:
        lines.append("Error lessons:")
        lines.extend(f"- {lesson}" for lesson in patterns if lesson)
    if len(lines) == 1:
        lines.append("No prior lessons.")
    return "\n".join(lines)


def classify_result(result: ExecutionResult) -> tuple[str, str]:
    if result.passed:
        return "passed", "Run a final mental check against edge cases before submitting."
    if result.status == "timeout":
        return "timeout", "Prefer bounded loops and verify that each iteration makes progress."
    stderr = result.stderr or ""
    if "SyntaxError" in stderr or "IndentationError" in stderr:
        return "syntax", "Check syntax, indentation, and balanced delimiters before submitting."
    if "NameError" in stderr:
        return "name_error", "Verify names and helper functions are defined before use."
    if "TypeError" in stderr:
        return "type_error", "Check input types, return types, and operator compatibility."
    if "IndexError" in stderr:
        return "index_error", "Check empty inputs and index boundaries before indexing."
    if "RecursionError" in stderr:
        return "recursion", "Use a valid base case and avoid unbounded recursive depth."
    if "AssertionError" in stderr:
        return "test_failure", "Check empty inputs, boundaries, duplicates, and off-by-one conditions."
    return "other_failure", "Use the failure category to revise only the incorrect assumption."


def update_memory_after_task(memory: MemoryState, results: Iterable[ExecutionResult]) -> MemoryState:
    """Update persistent memory once per task, after all attempts are finished.

    This freezes cross-task memory during retries, preventing the stateful variant from
    receiving an extra within-task adaptation channel that the stateless baseline lacks.
    """
    observations = list(results)
    updated = deepcopy(memory)
    updated.strategy_stats["tasks_seen"] = updated.strategy_stats.get("tasks_seen", 0) + 1

    if observations and observations[-1].passed:
        updated.strategy_stats["tasks_passed"] = updated.strategy_stats.get("tasks_passed", 0) + 1
    else:
        updated.strategy_stats["tasks_failed"] = updated.strategy_stats.get("tasks_failed", 0) + 1

    for result in observations:
        category, candidate = classify_result(result)
        updated.strategy_stats[category] = updated.strategy_stats.get(category, 0) + 1
        rule = sanitize_rule(candidate)
        if not rule:
            continue
        if rule not in updated.general_rules:
            updated.general_rules.append(rule)
        if not result.passed:
            item = {"category": category, "lesson": rule}
            if item not in updated.error_patterns:
                updated.error_patterns.append(item)

    updated.general_rules = updated.general_rules[-16:]
    updated.error_patterns = updated.error_patterns[-12:]
    return updated
