from __future__ import annotations

import hashlib
import re
from copy import deepcopy

from .memory import render_memory, update_memory_after_task
from .providers.base import ModelProvider
from .schemas import AttemptRecord, ExecutionResult, MemoryState, TaskRunRecord, TaskSpec

_COMMON_SYSTEM = """You are a coding benchmark agent. Produce only Python source code or the requested continuation. Do not use Markdown. Do not access files, the network, subprocesses, environment variables, or external packages. Solve only the stated function."""


def extract_code(text: str) -> str:
    stripped = text.strip()
    fenced = re.search(r"```(?:python)?\s*(.*?)```", stripped, re.DOTALL | re.IGNORECASE)
    return (fenced.group(1) if fenced else stripped).strip() + "\n"


def assemble_source(task: TaskSpec, generated: str) -> tuple[str, str]:
    """Return candidate code and the private executable source separately."""
    candidate = extract_code(generated)
    if task.code_prefix:
        if re.search(rf"\bdef\s+{re.escape(task.entry_point)}\s*\(", candidate):
            body = candidate
        else:
            body = task.code_prefix + candidate
    else:
        body = candidate
    parts = [body, task.tests]
    if task.check_call:
        parts.append(task.check_call)
    execution_source = "\n\n".join(parts) + "\n"
    return candidate, execution_source


def sanitized_feedback(result: ExecutionResult) -> str:
    """Return only a broad failure category, never hidden assertions or traceback source lines."""
    if result.status == "timeout":
        return "Execution timed out. Check termination and algorithmic complexity."
    if result.status == "sandbox_error":
        return "The isolated runner failed. Produce a minimal standard-library-only solution."
    stderr = result.stderr or ""
    categories = [
        ("SyntaxError", "Syntax error. Check syntax, indentation, and delimiters."),
        ("IndentationError", "Indentation error. Check block structure."),
        ("NameError", "Name error. Check that every referenced name is defined."),
        ("TypeError", "Type error. Check input and return types."),
        ("IndexError", "Index error. Check empty inputs and boundaries."),
        ("ZeroDivisionError", "Division-by-zero error. Handle zero denominators."),
        ("RecursionError", "Recursion error. Check the base case and recursion depth."),
        ("AssertionError", "One or more private tests failed. Re-check the specification and edge cases."),
    ]
    for marker, message in categories:
        if marker in stderr:
            return message
    return "Execution failed. Re-check the specification, edge cases, and return value."


class CodingAgent:
    def __init__(self, provider: ModelProvider, *, stateful: bool, max_attempts: int = 3) -> None:
        self.provider = provider
        self.stateful = stateful
        self.max_attempts = max_attempts
        self.memory = MemoryState()

    @property
    def variant(self) -> str:
        return "stateful" if self.stateful else "stateless"

    def solve(self, task: TaskSpec, sandbox, *, run_id: int, order_seed: int, order_index: int) -> TaskRunRecord:
        memory_before = deepcopy(self.memory).to_dict() if self.stateful else MemoryState().to_dict()
        attempts: list[AttemptRecord] = []
        executions: list[ExecutionResult] = []
        transitions = ["A"]
        total_input = total_output = total_cached = total_reasoning = total_tokens = 0
        total_cost: float | None = 0.0
        total_latency = 0.0
        prior_feedback = ""

        for attempt_number in range(1, self.max_attempts + 1):
            system_prompt = _COMMON_SYSTEM
            if self.stateful:
                system_prompt += "\n\nPersisted general memory (never copy prior solutions):\n" + render_memory(self.memory)
            user_prompt = task.model_prompt
            if prior_feedback:
                user_prompt += (
                    "\n\nThe previous attempt failed in the isolated test runner. Revise the solution. "
                    f"Sanitized failure feedback: {prior_feedback}"
                )

            response = self.provider.generate(system_prompt=system_prompt, user_prompt=user_prompt)
            candidate_code, execution_source = assemble_source(task, response.text)
            execution = sandbox.run(execution_source)
            executions.append(execution)
            total_input += response.input_tokens
            total_output += response.output_tokens
            total_cached += response.cached_input_tokens
            total_reasoning += response.reasoning_tokens
            total_tokens += response.total_tokens or (response.input_tokens + response.output_tokens)
            if response.cost_usd is None:
                total_cost = None
            elif total_cost is not None:
                total_cost += response.cost_usd
            total_latency += response.latency_ms + execution.duration_ms
            retry_reason = "" if execution.passed else sanitized_feedback(execution)
            attempts.append(
                AttemptRecord(
                    attempt=attempt_number,
                    generated_code=candidate_code,
                    execution_source_sha256=hashlib.sha256(execution_source.encode("utf-8")).hexdigest(),
                    passed=execution.passed,
                    execution_status=execution.status,
                    stdout=execution.stdout,
                    stderr=execution.stderr,
                    tokens_input=response.input_tokens,
                    tokens_output=response.output_tokens,
                    cached_input_tokens=response.cached_input_tokens,
                    reasoning_tokens=response.reasoning_tokens,
                    total_tokens=response.total_tokens or (response.input_tokens + response.output_tokens),
                    cost_usd=response.cost_usd,
                    latency_ms=response.latency_ms + execution.duration_ms,
                    provider_model=response.model,
                    provider_request_id=response.request_id,
                    retry_reason=retry_reason,
                )
            )
            if execution.passed:
                break
            transitions.extend(["Q", "A"])
            prior_feedback = retry_reason

        final_execution = executions[-1]
        if self.stateful:
            self.memory = update_memory_after_task(self.memory, executions)
            memory_after = deepcopy(self.memory).to_dict()
        else:
            memory_after = MemoryState().to_dict()

        return TaskRunRecord(
            task_id=task.task_id,
            variant=self.variant,  # type: ignore[arg-type]
            run_id=run_id,
            order_seed=order_seed,
            order_index=order_index,
            passed=final_execution.passed,
            passed_first_attempt=bool(attempts and attempts[0].passed),
            attempts=len(attempts),
            tokens_input=total_input,
            tokens_output=total_output,
            cached_input_tokens=total_cached,
            reasoning_tokens=total_reasoning,
            total_tokens=total_tokens,
            cost_usd=total_cost,
            latency_ms=total_latency,
            memory_before=memory_before,
            memory_after=memory_after,
            transitions_aq=transitions,
            attempt_records=attempts,
        )
