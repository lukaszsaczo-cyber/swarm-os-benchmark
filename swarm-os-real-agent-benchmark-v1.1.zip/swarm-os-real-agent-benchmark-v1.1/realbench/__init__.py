"""SWARM_OS real-agent benchmark harness."""

__version__ = "0.2.0"
MEMORY_POLICY_VERSION = "1.1.0"
