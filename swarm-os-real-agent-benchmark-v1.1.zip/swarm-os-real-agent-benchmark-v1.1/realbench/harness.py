from __future__ import annotations

import json
import random
from pathlib import Path
from typing import Iterable

from .agents import CodingAgent
from .schemas import TaskRunRecord, TaskSpec


def select_tasks(tasks: Iterable[TaskSpec], limit: int, seed: int) -> list[TaskSpec]:
    pool = list(tasks)
    if limit <= 0:
        raise ValueError("task limit must be positive")
    if limit >= len(pool):
        return pool
    indices = sorted(random.Random(seed).sample(range(len(pool)), limit))
    return [pool[index] for index in indices]


def ordered_tasks(tasks: Iterable[TaskSpec], seed: int) -> list[TaskSpec]:
    ordered = list(tasks)
    random.Random(seed).shuffle(ordered)
    return ordered


def run_variant(
    *,
    tasks: Iterable[TaskSpec],
    agent: CodingAgent,
    sandbox,
    run_id: int,
    order_seed: int,
    output_path: Path,
) -> list[TaskRunRecord]:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    records: list[TaskRunRecord] = []
    with output_path.open("a", encoding="utf-8") as handle:
        for index, task in enumerate(ordered_tasks(tasks, order_seed)):
            record = agent.solve(
                task,
                sandbox,
                run_id=run_id,
                order_seed=order_seed,
                order_index=index,
            )
            records.append(record)
            handle.write(json.dumps(record.to_dict(), ensure_ascii=False) + "\n")
            handle.flush()
    return records
