from __future__ import annotations

from .schemas import TaskSpec


def pilot_tasks() -> list[TaskSpec]:
    rows = [
        ("pilot/add", "Implement add(a, b).", "assert add(2, 3) == 5\nassert add(-2, 2) == 0"),
        ("pilot/reverse_string", "Implement reverse_string(text).", "assert reverse_string('abc') == 'cba'\nassert reverse_string('') == ''"),
        ("pilot/is_palindrome", "Implement is_palindrome(text).", "assert is_palindrome('level') is True\nassert is_palindrome('python') is False"),
        ("pilot/factorial", "Implement factorial(n) for non-negative integers and raise ValueError for negatives.", "assert factorial(0) == 1\nassert factorial(5) == 120\ntry:\n    factorial(-1)\nexcept ValueError:\n    pass\nelse:\n    raise AssertionError('expected ValueError')"),
        ("pilot/fibonacci", "Implement fibonacci(n) with fibonacci(0)=0 and fibonacci(1)=1.", "assert fibonacci(0) == 0\nassert fibonacci(1) == 1\nassert fibonacci(10) == 55"),
        ("pilot/gcd", "Implement gcd(a, b) for signed integers.", "assert gcd(48, 18) == 6\nassert gcd(-12, 8) == 4\nassert gcd(0, 5) == 5"),
        ("pilot/dedupe", "Implement dedupe(values), preserving first-seen order.", "assert dedupe([1, 2, 1, 3, 2]) == [1, 2, 3]\nassert dedupe([]) == []"),
        ("pilot/count_vowels", "Implement count_vowels(text), case-insensitive.", "assert count_vowels('OpenAI') == 4\nassert count_vowels('rhythm') == 0"),
        ("pilot/flatten_one", "Implement flatten_one(items) for a list of lists.", "assert flatten_one([[1, 2], [], [3]]) == [1, 2, 3]\nassert flatten_one([]) == []"),
        ("pilot/binary_search", "Implement binary_search(values, target), returning an index or -1.", "assert binary_search([1, 3, 5, 7], 5) == 2\nassert binary_search([1, 3, 5, 7], 2) == -1\nassert binary_search([], 1) == -1"),
    ]
    return [
        TaskSpec(
            task_id=task_id,
            model_prompt=f"TASK_ID: {task_id}\n{prompt}\nReturn Python code only, with no Markdown fences.",
            code_prefix="",
            tests=tests,
            entry_point=task_id.rsplit("/", 1)[-1],
        )
        for task_id, prompt, tests in rows
    ]


def humaneval_tasks() -> list[TaskSpec]:
    try:
        from human_eval.data import read_problems
    except ImportError as exc:
        raise RuntimeError("Install HumanEval: pip install -e '.[humaneval]'") from exc

    problems = read_problems()
    tasks: list[TaskSpec] = []
    for task_id, problem in problems.items():
        prompt = problem["prompt"]
        entry_point = problem["entry_point"]
        tasks.append(
            TaskSpec(
                task_id=task_id,
                model_prompt=(
                    f"TASK_ID: {task_id}\nComplete the Python function below. Return only the missing "
                    f"continuation after the provided prefix, with no Markdown fences.\n\n{prompt}"
                ),
                code_prefix=prompt,
                tests=problem["test"],
                check_call=f"check({entry_point})",
                entry_point=entry_point,
            )
        )
    return tasks
