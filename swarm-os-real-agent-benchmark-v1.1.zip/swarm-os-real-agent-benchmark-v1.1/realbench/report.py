from __future__ import annotations

import json
from collections import defaultdict
from pathlib import Path
from statistics import mean
from typing import Any


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    rows = []
    with path.open(encoding="utf-8") as handle:
        for line in handle:
            if line.strip():
                rows.append(json.loads(line))
    return rows


def _sum_optional_cost(items: list[dict[str, Any]]) -> float | None:
    values = [item.get("cost_usd") for item in items]
    if any(value is None for value in values):
        return None
    return sum(float(value) for value in values)


def summarize(rows: list[dict[str, Any]]) -> dict[str, Any]:
    groups: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        groups[row["variant"]].append(row)

    report: dict[str, Any] = {"variants": {}}
    for variant, items in groups.items():
        count = len(items)
        report["variants"][variant] = {
            "task_runs": count,
            "unique_tasks": len({item["task_id"] for item in items}),
            "runs": len({int(item["run_id"]) for item in items}),
            "pass_at_1": sum(bool(item["passed_first_attempt"]) for item in items) / count,
            "success_within_budget": sum(bool(item["passed"]) for item in items) / count,
            "mean_attempts": mean(int(item["attempts"]) for item in items),
            "tokens_input": sum(int(item["tokens_input"]) for item in items),
            "tokens_output": sum(int(item["tokens_output"]) for item in items),
            "cached_input_tokens": sum(int(item.get("cached_input_tokens", 0)) for item in items),
            "reasoning_tokens": sum(int(item.get("reasoning_tokens", 0)) for item in items),
            "total_tokens": sum(int(item.get("total_tokens", 0)) for item in items),
            "cost_usd": _sum_optional_cost(items),
            "mean_latency_ms": mean(float(item["latency_ms"]) for item in items),
        }

    paired: dict[tuple[str, int], dict[str, dict[str, Any]]] = defaultdict(dict)
    for row in rows:
        paired[(row["task_id"], int(row["run_id"]))][row["variant"]] = row
    complete_pairs = [pair for pair in paired.values() if {"stateful", "stateless"} <= set(pair)]
    if complete_pairs:
        paired_cost_available = all(
            pair["stateful"].get("cost_usd") is not None and pair["stateless"].get("cost_usd") is not None
            for pair in complete_pairs
        )
        report["paired"] = {
            "pairs": len(complete_pairs),
            "delta_pass_at_1": mean(
                int(pair["stateful"]["passed_first_attempt"]) - int(pair["stateless"]["passed_first_attempt"])
                for pair in complete_pairs
            ),
            "delta_success_within_budget": mean(
                int(pair["stateful"]["passed"]) - int(pair["stateless"]["passed"])
                for pair in complete_pairs
            ),
            "delta_input_tokens": sum(
                int(pair["stateful"]["tokens_input"]) - int(pair["stateless"]["tokens_input"])
                for pair in complete_pairs
            ),
            "delta_cached_input_tokens": sum(
                int(pair["stateful"].get("cached_input_tokens", 0))
                - int(pair["stateless"].get("cached_input_tokens", 0))
                for pair in complete_pairs
            ),
            "delta_output_tokens": sum(
                int(pair["stateful"]["tokens_output"]) - int(pair["stateless"]["tokens_output"])
                for pair in complete_pairs
            ),
            "delta_reasoning_tokens": sum(
                int(pair["stateful"].get("reasoning_tokens", 0))
                - int(pair["stateless"].get("reasoning_tokens", 0))
                for pair in complete_pairs
            ),
            "delta_cost_usd": (
                sum(
                    float(pair["stateful"]["cost_usd"]) - float(pair["stateless"]["cost_usd"])
                    for pair in complete_pairs
                )
                if paired_cost_available
                else None
            ),
        }
    return report


def write_report(jsonl_path: Path, report_path: Path) -> dict[str, Any]:
    report = summarize(load_jsonl(jsonl_path))
    report_path.write_text(json.dumps(report, indent=2, sort_keys=True), encoding="utf-8")
    return report
