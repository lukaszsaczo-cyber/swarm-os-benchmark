from __future__ import annotations

import argparse
import json
import os
from datetime import datetime, timezone
from pathlib import Path

from . import MEMORY_POLICY_VERSION, __version__
from .agents import CodingAgent
from .datasets import humaneval_tasks, pilot_tasks
from .harness import run_variant, select_tasks
from .providers import MockProvider, OpenAIProvider
from .report import write_report
from .sandbox import DockerPythonSandbox, LocalPythonSandbox, TrustedPythonSandbox


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="SWARM_OS real-agent benchmark")
    parser.add_argument("--provider", choices=["mock", "openai"], default="mock")
    parser.add_argument("--model", default=None)
    parser.add_argument("--dataset", choices=["pilot", "humaneval"], default="pilot")
    parser.add_argument("--task-limit", type=int, default=10)
    parser.add_argument("--selection-seed", type=int, default=20260731)
    parser.add_argument("--runs", type=int, default=1)
    parser.add_argument("--max-attempts", type=int, default=3)
    parser.add_argument("--order-seed", type=int, default=42)
    parser.add_argument("--sandbox", choices=["trusted", "local", "docker"], default="trusted")
    parser.add_argument("--output-dir", default="results")
    return parser


def variant_order(run_id: int) -> tuple[bool, bool]:
    """Counterbalance temporal API effects across runs."""
    return (False, True) if run_id % 2 == 1 else (True, False)


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    provider = MockProvider() if args.provider == "mock" else OpenAIProvider.from_env(args.model)
    all_tasks = pilot_tasks() if args.dataset == "pilot" else humaneval_tasks()
    tasks = select_tasks(all_tasks, args.task_limit, args.selection_seed)
    sandbox = (
        TrustedPythonSandbox() if args.sandbox == "trusted"
        else LocalPythonSandbox() if args.sandbox == "local"
        else DockerPythonSandbox()
    )
    if args.provider != "mock" and args.sandbox == "trusted":
        raise SystemExit("The trusted sandbox is permitted only with --provider mock")
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    jsonl_path = output_dir / "raw_results.jsonl"
    if jsonl_path.exists():
        jsonl_path.unlink()

    manifest = {
        "harness_version": __version__,
        "memory_policy_version": MEMORY_POLICY_VERSION,
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "git_sha": os.getenv("GITHUB_SHA", ""),
        "provider": args.provider,
        "model": provider.model,
        "dataset": args.dataset,
        "selected_task_ids": [task.task_id for task in tasks],
        "task_limit": len(tasks),
        "selection_seed": args.selection_seed,
        "runs": args.runs,
        "max_attempts": args.max_attempts,
        "order_seed": args.order_seed,
        "variant_order_by_run": {
            str(run_id): ["stateful" if stateful else "stateless" for stateful in variant_order(run_id)]
            for run_id in range(1, args.runs + 1)
        },
        "sandbox": args.sandbox,
    }
    (output_dir / "experiment_manifest.json").write_text(
        json.dumps(manifest, indent=2, sort_keys=True), encoding="utf-8"
    )

    for run_id in range(1, args.runs + 1):
        seed = args.order_seed + run_id - 1
        for stateful in variant_order(run_id):
            agent = CodingAgent(provider, stateful=stateful, max_attempts=args.max_attempts)
            run_variant(
                tasks=tasks,
                agent=agent,
                sandbox=sandbox,
                run_id=run_id,
                order_seed=seed,
                output_path=jsonl_path,
            )

    report = write_report(jsonl_path, output_dir / "summary.json")
    for variant, metrics in report["variants"].items():
        print(variant, metrics)
    print("paired", report.get("paired", {}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
