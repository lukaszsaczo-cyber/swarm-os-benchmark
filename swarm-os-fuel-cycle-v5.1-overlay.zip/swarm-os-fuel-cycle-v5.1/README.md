# SWARM OS Fuel Cycle v5.1 overlay

This patch updates the existing Pull Request #3 branch `agent/fuel-cycle-v5`.

Core correction:

`loss of fit with the wider system -> reduced energy recovery -> fuel drain -> rising tension -> weakening regulation -> accumulated mismatch load -> PĘKNIĘCIE -> ROZPAD II`

There is no task-count timeout for stagnation. Recovery to `RYTM` remains possible when whole-system alignment, fuel and balance are restored.

Local verification included in this package:
- compilation passed;
- 23 tests repeated three times: 69/69 passed;
- three deterministic paired 10x10 simulations completed;
- 20% token-reduction hypothesis remains `NOT_CONFIRMED`.
