#!/usr/bin/env bash
set -euo pipefail

PACKAGE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(git rev-parse --show-toplevel)"
BRANCH="agent/fuel-cycle-v5"

cd "$REPO_ROOT"
git fetch origin
git switch "$BRANCH"
git pull --ff-only origin "$BRANCH"
cp -a "$PACKAGE_DIR/github_overlay/." "$REPO_ROOT/"

cd "$REPO_ROOT/validation_10x10"
python -m compileall -q swarm_validation scripts
for run in 1 2 3; do
  echo "=== Fuel Cycle v5.1 test run $run ==="
  PYTHONPATH=. python -m unittest discover -s swarm_validation/tests -v
done

SIM_ROOT="/tmp/swarm-fuel-cycle-v5-1-simulation"
rm -rf "$SIM_ROOT"
SWARM_SIM_ROOT="$SIM_ROOT" PYTHONPATH=. python scripts/triple_cycle_simulation.py \
  | tee /tmp/swarm-fuel-cycle-v5-1-simulation.json

cd "$REPO_ROOT"
git add \
  validation_10x10/swarm_validation/controller.py \
  validation_10x10/swarm_validation/models.py \
  validation_10x10/swarm_validation/protocol.py \
  validation_10x10/swarm_validation/runner.py \
  validation_10x10/swarm_validation/tests/test_core.py \
  validation_10x10/swarm_validation/tests/test_memory_cycle_v4.py \
  validation_10x10/scripts/triple_cycle_simulation.py \
  validation_10x10/FUEL_CYCLE_V5_1.md

if git diff --cached --quiet; then
  echo "No changes to commit. The v5.1 correction may already be applied."
else
  git commit -m "Make stagnation mismatch-energy driven"
  git push origin "$BRANCH"
fi

echo
echo "Updated Pull Request:"
echo "https://github.com/lukaszsaczo-cyber/swarm-os-benchmark/pull/3"
