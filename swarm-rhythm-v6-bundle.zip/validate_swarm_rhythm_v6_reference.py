from __future__ import annotations

from dataclasses import dataclass, field
from statistics import fmean, pstdev
import math
import unittest


def clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, value))


@dataclass
class State:
    fuel: float = 1.0
    vertical_alignment: float = 0.5
    regulation: float = 0.5
    tension: float = 0.25
    rhythm_alignment: float = 0.5
    token_value: float = 0.0
    token_value_equilibrium: float = 0.5
    token_value_trend: float = 0.0
    token_value_volatility: float = 0.0
    token_value_history: list[float] = field(default_factory=list)
    rhythm_direction: str = "stable"
    cycle_index: int = 0
    phase: str = "RÓŻNICA"


class Probe:
    output_token_weight = 5.0
    token_reference_weighted_tokens = 1000.0
    rhythm_window = 6
    token_equilibrium_alpha = 0.08

    def __init__(self) -> None:
        self.state = State()
        self.working: list[str] = []
        self.pending: list[str] = []
        self.intuition: list[tuple[int, str]] = []

    def instant_value(self, quality: float, input_tokens: int, output_tokens: int) -> float:
        weighted = input_tokens + self.output_token_weight * output_tokens
        cost_units = max(weighted / self.token_reference_weighted_tokens, 1e-9)
        raw = max(0.0, quality) / cost_units
        return clamp(raw / (1.0 + raw))

    @staticmethod
    def slope(values: list[float]) -> float:
        if len(values) < 2:
            return 0.0
        xm = (len(values) - 1) / 2.0
        ym = fmean(values)
        den = sum((i - xm) ** 2 for i in range(len(values)))
        return sum((i - xm) * (v - ym) for i, v in enumerate(values)) / den

    def update(self, quality: float, input_tokens: int, output_tokens: int) -> None:
        s = self.state
        s.vertical_alignment = clamp(0.65 * s.vertical_alignment + 0.35 * quality)
        value = self.instant_value(quality, input_tokens, output_tokens)
        s.token_value = value
        history = (s.token_value_history + [value])[-self.rhythm_window :]
        s.token_value_history = history
        equilibrium = max(s.token_value_equilibrium, 1e-6)
        mean_value = fmean(history)
        volatility = clamp(pstdev(history) / max(mean_value, 0.05)) if len(history) >= 2 else 0.0
        trend = self.slope(history) / max(s.token_value_equilibrium, 0.05)
        s.token_value_volatility = volatility
        s.token_value_trend = trend
        level_fit = math.exp(-2.0 * abs(math.log((mean_value + 1e-6) / (equilibrium + 1e-6))))
        direction_fit = math.exp(-3.0 * abs(trend))
        instant_rhythm = clamp(max(0.0, level_fit * (1.0 - volatility) * direction_fit) ** (1.0 / 3.0))
        s.rhythm_alignment = clamp(0.65 * s.rhythm_alignment + 0.35 * instant_rhythm)
        if (
            quality >= 0.70
            and s.vertical_alignment >= 0.55
            and len(history) >= 3
            and volatility <= 0.12
            and abs(trend) <= 0.05
            and level_fit >= 0.65
        ):
            a = self.token_equilibrium_alpha
            s.token_value_equilibrium = (1.0 - a) * s.token_value_equilibrium + a * mean_value
        if volatility >= 0.30:
            s.rhythm_direction = "oscillating"
        elif trend <= -0.05:
            s.rhythm_direction = "falling"
        elif trend >= 0.05:
            s.rhythm_direction = "rising"
        elif mean_value < 0.85 * equilibrium:
            s.rhythm_direction = "below_equilibrium"
        elif mean_value > 1.15 * equilibrium:
            s.rhythm_direction = "above_equilibrium"
        else:
            s.rhythm_direction = "stable"

        stress = 0.0 if quality >= 0.70 else 0.65
        s.tension = clamp(0.70 * s.tension + 0.45 * (1.0 - quality) + 0.35 * stress - 0.25 * quality)
        deviation = 1.0 - s.vertical_alignment
        s.regulation = clamp(s.regulation + 0.14 * quality - 0.18 * stress - 0.08 * deviation)
        rhythm_deviation = 1.0 - s.rhythm_alignment
        gain = (0.12 * quality + 0.06 * s.regulation) * s.rhythm_alignment
        cost = 0.040 + 0.16 * deviation + 0.22 * rhythm_deviation + 0.12 * s.tension + 0.10 * stress
        s.fuel = clamp(s.fuel + gain - cost, 0.0, 1.25)

    def prompt(self) -> str:
        if self.state.phase == "40":
            self.intuition.extend((self.state.cycle_index, x) for x in self.pending)
            self.pending.clear()
            self.working.clear()
            self.state.cycle_index += 1
            self.state.phase = "RÓŻNICA"
        usable = [lesson for cycle, lesson in self.intuition if cycle < self.state.cycle_index]
        return "BASE" if not usable else "BASE\nPrior-cycle intuition:\n" + "\n".join(usable)

    def collapse(self) -> None:
        self.state.phase = "3"
        residue = [x for x in self.working if x]
        self.state.phase = "6"
        cleaned = list(dict.fromkeys(residue))
        self.state.phase = "28"
        self.pending = ["Cycle update: " + "; ".join(cleaned)] if len(cleaned) >= 2 else []
        self.state.phase = "40"


class RhythmTests(unittest.TestCase):
    def test_stable_near_target(self) -> None:
        p = Probe()
        for _ in range(10):
            p.update(1.0, 400, 80)
        self.assertGreater(p.state.rhythm_alignment, 0.90)
        self.assertEqual(p.state.rhythm_direction, "stable")
        self.assertLess(p.state.token_value_volatility, 0.01)

    def test_same_quality_higher_cost_loses_rhythm_and_fuel(self) -> None:
        good, waste = Probe(), Probe()
        for _ in range(8):
            good.update(1.0, 400, 80)
            waste.update(1.0, 2200, 400)
        self.assertGreater(good.state.rhythm_alignment, waste.state.rhythm_alignment)
        self.assertGreater(good.state.fuel, waste.state.fuel)
        self.assertEqual(waste.state.rhythm_direction, "below_equilibrium")

    def test_falling_value_detected_before_total_failure(self) -> None:
        p = Probe()
        for _ in range(6):
            p.update(1.0, 400, 80)
        before = p.state.rhythm_alignment
        for inp, out in [(700, 120), (1000, 180), (1500, 250), (2200, 350)]:
            p.update(1.0, inp, out)
        self.assertLess(p.state.rhythm_alignment, before)
        self.assertLess(p.state.token_value_trend, 0.0)
        self.assertIn(p.state.rhythm_direction, {"falling", "oscillating"})

    def test_oscillation_is_not_equilibrium(self) -> None:
        p = Probe()
        for inp, out in [(100, 20), (2400, 420)] * 5:
            p.update(1.0, inp, out)
        self.assertGreater(p.state.token_value_volatility, 0.30)
        self.assertEqual(p.state.rhythm_direction, "oscillating")
        self.assertLess(p.state.rhythm_alignment, 0.65)

    def test_failure_destroys_value(self) -> None:
        p = Probe()
        for _ in range(6):
            p.update(1.0, 400, 80)
        p.update(0.0, 1600, 300)
        self.assertEqual(p.state.token_value, 0.0)
        self.assertLess(p.state.token_value_trend, 0.0)


class MemoryBoundaryTests(unittest.TestCase):
    def test_working_memory_never_reaches_prompt(self) -> None:
        p = Probe()
        p.working = ["raw current evidence"]
        self.assertEqual(p.prompt(), "BASE")

    def test_memory_only_after_3_6_28_40(self) -> None:
        p = Probe()
        p.working = ["preserve original positions", "normalize both sides"]
        p.collapse()
        self.assertEqual(p.state.phase, "40")
        self.assertEqual(p.intuition, [])
        prompt = p.prompt()
        self.assertEqual(p.state.cycle_index, 1)
        self.assertIn("Prior-cycle intuition", prompt)
        self.assertIn("Cycle update", prompt)

    def test_one_off_noise_does_not_survive(self) -> None:
        p = Probe()
        p.working = ["one-off"]
        p.collapse()
        self.assertEqual(p.prompt(), "BASE")

    def test_prior_cycle_memory_persists_when_fuel_is_low(self) -> None:
        p = Probe()
        p.intuition = [(0, "Cycle update: proven rule")]
        p.state.cycle_index = 1
        p.state.fuel = 0.1
        self.assertIn("proven rule", p.prompt())


if __name__ == "__main__":
    unittest.main(verbosity=2)
