SWARM_OS v6 — instalacja i test 30 nowych projektów

1. Umieść plik apply_swarm_rhythm_v6.py w katalogu głównym repozytorium:
   /workspaces/swarm-os-benchmark/

2. W terminalu Codespace uruchom jedną komendę:

   cd /workspaces/swarm-os-benchmark && python apply_swarm_rhythm_v6.py --repo /workspaces/swarm-os-benchmark --live

Instalator:
- tworzy gałąź agent/rhythm-token-value-v6,
- poprawia RYTM jako stabilną wartość ważonego przepływu tokenów,
- wyłącza pamięć roboczą w promptach,
- udostępnia intuicję dopiero po ROZPAD II -> 3 -> 6 -> 28 -> 40,
- zachowuje intuicję przy niskim paliwie i podczas retry,
- uruchamia wszystkie testy jednostkowe,
- generuje 30 nowych projektów po 16 etapów,
- uruchamia 3 zamrożone partie testu 10x10 przez Claude API,
- tworzy raport łączny dla 30 projektów,
- commit/push i próbuje otworzyć PR.

Uwaga: wymagany jest ANTHROPIC_API_KEY w Codespace. Test live może wykonać maksymalnie 2880 wywołań API w najgorszym przypadku.

SHA-256 apply_swarm_rhythm_v6.py:
d0586b1e76cf9c6820fd83bd5318f2ce525864d8f9d0c86473e778c95dd58377
