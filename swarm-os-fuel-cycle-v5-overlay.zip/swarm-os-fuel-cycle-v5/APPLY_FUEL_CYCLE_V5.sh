#!/usr/bin/env bash
set -euo pipefail

PACKAGE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(git rev-parse --show-toplevel)"
BRANCH="agent/fuel-cycle-v5"

cd "$REPO_ROOT"
git switch main
git pull --ff-only
if git show-ref --verify --quiet "refs/heads/$BRANCH"; then
  git branch -D "$BRANCH"
fi
git switch -c "$BRANCH"
cp -a "$PACKAGE_DIR/github_overlay/." "$REPO_ROOT/"

cd "$REPO_ROOT/validation_10x10"
python -m compileall -q swarm_validation scripts
for run in 1 2 3; do
  echo "=== Fuel Cycle v5 test run $run ==="
  PYTHONPATH=. python -m unittest discover -s swarm_validation/tests -v
done

SIM_ROOT="/tmp/swarm-fuel-cycle-v5-simulation"
rm -rf "$SIM_ROOT"
SWARM_SIM_ROOT="$SIM_ROOT" PYTHONPATH=. python scripts/triple_cycle_simulation.py \
  | tee /tmp/swarm-fuel-cycle-v5-simulation.json

cd "$REPO_ROOT"
git add \
  validation_10x10/swarm_validation/analysis.py \
  validation_10x10/swarm_validation/models.py \
  validation_10x10/swarm_validation/protocol.py \
  validation_10x10/swarm_validation/controller.py \
  validation_10x10/swarm_validation/runner.py \
  validation_10x10/swarm_validation/tests/test_core.py \
  validation_10x10/swarm_validation/tests/test_memory_cycle_v4.py \
  validation_10x10/scripts/triple_cycle_simulation.py \
  validation_10x10/examples/fuel_cycle_v5_pilot.json \
  validation_10x10/FUEL_CYCLE_V5.md \
  validation_10x10/FUEL_CYCLE_V5_TEST_RESULTS.md \
  validation_10x10/results/fuel-cycle-v5-synthetic/summary.json

git commit -m "Implement fuel-directed cycle and second collapse"
git push -u origin "$BRANCH"

PR_BODY=$(cat <<'EOF'
Implements fuel as a causal control variable and replaces count-driven cycle closure.

Canonical path:
RÓŻNICA -> NAPIĘCIE -> REGULACJA -> DOPASOWANIE -> PION -> KRYSTALIZACJA -> RYTM -> STAGNACJA -> PĘKNIĘCIE -> ROZPAD II -> 3 -> 6 -> 28 -> 40 -> RÓŻNICA.

ROZPAD I can recover to REGULACJA in the same cycle. ROZPAD II is possible only after crystallization and persistent rhythm loss. State 40 remains the threshold; the next cycle starts through RÓŻNICA with refreshed intuition.

Verification: compilation passed, 21 tests repeated three times (63/63), and three paired 10x10 engineering simulations. The rebirth simulation produced 7.80% token reduction with equal quality; the 20% live hypothesis remains NOT_CONFIRMED.
EOF
)

gh pr create \
  --base main \
  --head "$BRANCH" \
  --title "Implement fuel-directed cycle and second collapse" \
  --body "$PR_BODY"
