# SWARM_OS Fuel Cycle v5 overlay

This package is based on the current Memory Cycle v4 code already merged into `main`.
It changes the cycle trigger from a fixed task count to fuel, vertical alignment,
balance, crystallization and rhythm dynamics.

Run `APPLY_FUEL_CYCLE_V5.sh` from inside the repository after unpacking the ZIP.
The script creates a branch, applies the overlay, runs 63 tests and three paired
10x10 simulations, commits, pushes and opens a pull request.
